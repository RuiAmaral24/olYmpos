
  # olYmpos — UI Add / Edit Entry Modal

  This is a code bundle for olYmpos — UI Add / Edit Entry Modal. The original project is available at https://www.figma.com/design/bZRDX07sIRiV4SLqZcuUNL/olYmpos-%E2%80%94-UI-Add---Edit-Entry-Modal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  