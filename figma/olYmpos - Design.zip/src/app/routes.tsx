import { createBrowserRouter } from "react-router";
import LandingPage from "./pages/LandingPage";
import Dashboard from "./pages/Dashboard";
import Library from "./pages/Library";
import Profile from "./pages/Profile";
import ItemDetails from "./pages/ItemDetails";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
  {
    path: "/library",
    Component: Library,
  },
  {
    path: "/profile",
    Component: Profile,
  },
  {
    path: "/item/:id",
    Component: ItemDetails,
  },
]);