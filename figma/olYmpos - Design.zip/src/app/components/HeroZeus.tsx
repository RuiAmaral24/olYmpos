import { motion } from 'motion/react';
import zeusImage from '../../imports/image.png';

export default function HeroZeus() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Cosmic Background Layers - spread across hero */}
      <div className="absolute inset-0">
        {/* Primary cosmic glow behind Zeus - centered */}
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-br from-[#8b5cf6] via-[#6366f1] to-[#3b82f6] rounded-full blur-[160px] opacity-45"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.4, 0.55, 0.4],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />

        {/* Secondary purple glow - right side */}
        <motion.div
          className="absolute top-[35%] right-[15%] w-[600px] h-[600px] bg-[#a78bfa] rounded-full blur-[130px] opacity-35"
          animate={{
            scale: [1.1, 1, 1.1],
            opacity: [0.3, 0.4, 0.3],
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 1,
          }}
        />

        {/* Left accent glow for balance */}
        <motion.div
          className="absolute top-[45%] left-[10%] w-[500px] h-[500px] bg-[#6366f1] rounded-full blur-[120px] opacity-25"
          animate={{
            scale: [1, 1.15, 1],
            opacity: [0.2, 0.3, 0.2],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 2,
          }}
        />

        {/* Bottom atmospheric glow */}
        <motion.div
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[1000px] h-[400px] bg-gradient-to-t from-[#6366f1]/30 via-[#8b5cf6]/18 to-transparent blur-[110px]"
          animate={{
            opacity: [0.45, 0.65, 0.45],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 0.5,
          }}
        />
      </div>

      {/* Cosmic rings - centered */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full border border-[#8b5cf6]/12"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{
            scale: 1,
            opacity: 0.3,
            rotate: 360
          }}
          transition={{
            scale: { duration: 1.5 },
            opacity: { duration: 1.5 },
            rotate: { duration: 30, repeat: Infinity, ease: 'linear' }
          }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[900px] rounded-full border border-[#6366f1]/8"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{
            scale: 1,
            opacity: 0.2,
            rotate: -360
          }}
          transition={{
            scale: { duration: 1.5, delay: 0.2 },
            opacity: { duration: 1.5, delay: 0.2 },
            rotate: { duration: 35, repeat: Infinity, ease: 'linear' }
          }}
        />
      </div>

      {/* Zeus Image - full background coverage */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.5, delay: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
      >
        {/* Zeus atmospheric glow */}
        <motion.div
          className="absolute inset-0 -z-10"
          animate={{
            opacity: [0.6, 0.8, 0.6],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-[#8b5cf6]/20 via-[#6366f1]/15 to-[#3b82f6]/10 blur-[90px]" />
        </motion.div>

        {/* Zeus Image with extensive blending - full coverage */}
        <div className="relative w-full h-full min-h-[95vh]">
          <motion.img
            src={zeusImage}
            alt="Zeus"
            className="absolute inset-0 w-full h-full object-cover object-center"
            style={{
              opacity: 0.55,
              mixBlendMode: 'luminosity',
              maskImage: 'radial-gradient(ellipse 105% 95% at 52% 50%, black 18%, rgba(0,0,0,0.9) 35%, rgba(0,0,0,0.65) 55%, rgba(0,0,0,0.35) 75%, rgba(0,0,0,0.1) 90%, transparent 100%)',
              WebkitMaskImage: 'radial-gradient(ellipse 105% 95% at 52% 50%, black 18%, rgba(0,0,0,0.9) 35%, rgba(0,0,0,0.65) 55%, rgba(0,0,0,0.35) 75%, rgba(0,0,0,0.1) 90%, transparent 100%)',
            }}
          />

          {/* Overlay with normal blend to add color back */}
          <motion.img
            src={zeusImage}
            alt=""
            className="absolute inset-0 w-full h-full object-cover object-center"
            style={{
              opacity: 0.28,
              mixBlendMode: 'normal',
              maskImage: 'radial-gradient(ellipse 100% 90% at 52% 50%, black 12%, rgba(0,0,0,0.75) 30%, rgba(0,0,0,0.45) 50%, rgba(0,0,0,0.2) 70%, rgba(0,0,0,0.05) 85%, transparent 98%)',
              WebkitMaskImage: 'radial-gradient(ellipse 100% 90% at 52% 50%, black 12%, rgba(0,0,0,0.75) 30%, rgba(0,0,0,0.45) 50%, rgba(0,0,0,0.2) 70%, rgba(0,0,0,0.05) 85%, transparent 98%)',
            }}
            animate={{
              opacity: [0.23, 0.33, 0.23],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />

          {/* Soft purple glow overlay on Zeus - spread across */}
          <motion.div
            className="absolute inset-0"
            style={{
              background: 'radial-gradient(ellipse 90% 80% at 50% 45%, rgba(139,92,246,0.2), rgba(99,102,241,0.15) 35%, rgba(139,92,246,0.08) 60%, transparent 80%)',
              mixBlendMode: 'screen',
            }}
            animate={{
              opacity: [0.7, 0.95, 0.7],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 0.5,
            }}
          />

          {/* Light bloom effect */}
          <motion.div
            className="absolute inset-0"
            style={{
              background: 'radial-gradient(ellipse 75% 70% at 50% 45%, rgba(167,139,250,0.3), rgba(139,92,246,0.15) 45%, transparent 75%)',
              filter: 'blur(50px)',
            }}
            animate={{
              opacity: [0.55, 0.8, 0.55],
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 1,
            }}
          />
        </div>

        {/* Edge vignette to blend into background - all sides */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0f]/75 via-transparent to-[#0a0a0f]/60 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-l from-[#0a0a0f]/45 via-transparent to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f]/50 via-transparent to-[#0a0a0f]/95 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f]/70 via-[#0a0a0f]/25 to-[#0a0a0f]/50 pointer-events-none" />

        {/* Additional corner blending */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,#0a0a0f_0%,transparent_40%)] opacity-80 pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,#0a0a0f_0%,transparent_40%)] opacity-60 pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,#0a0a0f_0%,transparent_35%)] opacity-85 pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,#0a0a0f_0%,transparent_35%)] opacity-80 pointer-events-none" />

        {/* Enhanced bottom center blend for smoother transition */}
        <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-[#0a0a0f]/60 via-[#0a0a0f]/20 to-transparent pointer-events-none" />
      </motion.div>

      {/* Atmospheric particles */}
      <div className="absolute inset-0">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#a78bfa] rounded-full shadow-[0_0_10px_rgba(167,139,250,0.6)]"
            style={{
              left: `${30 + Math.random() * 60}%`,
              top: `${20 + Math.random() * 60}%`,
            }}
            animate={{
              opacity: [0, 0.6, 0],
              scale: [0.5, 1.2, 0.5],
              y: [0, -25, 0],
            }}
            transition={{
              duration: 5 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 4,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      {/* Cinematic gradient overlays for depth */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a0f]/25 via-transparent to-[#0a0a0f]/15 pointer-events-none" />
    </div>
  );
}
