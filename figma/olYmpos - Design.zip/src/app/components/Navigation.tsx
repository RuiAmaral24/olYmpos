import { motion } from 'motion/react';
import { Zap } from 'lucide-react';

interface NavigationProps {
  onLoginClick?: () => void;
  onSignUpClick?: () => void;
}

export default function Navigation({ onLoginClick, onSignUpClick }: NavigationProps) {
  return (
    <motion.nav
      className="fixed top-0 left-0 right-0 z-50 px-6 py-5 backdrop-blur-xl bg-[#0a0a0f]/80 border-b border-[#8b5cf6]/15"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
    >
      <div className="max-w-[1400px] mx-auto flex items-center justify-between">
        {/* Logo */}
        <motion.a
          href="#"
          className="flex items-center gap-3 group"
          whileHover={{ scale: 1.02 }}
          transition={{ duration: 0.2 }}
        >
          <div className="relative">
            <Zap className="w-7 h-7 text-[#8b5cf6] fill-[#8b5cf6] relative z-10 transition-all group-hover:text-[#a78bfa] group-hover:fill-[#a78bfa]" />
            <motion.div
              className="absolute inset-0 blur-lg bg-[#8b5cf6] opacity-40"
              animate={{
                opacity: [0.4, 0.6, 0.4],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
          </div>
          <span
            className="text-2xl tracking-tight bg-gradient-to-r from-[#f0f4ff] via-[#d4c5f9] to-[#a78bfa] bg-clip-text text-transparent"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            olYmpos
          </span>
        </motion.a>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-10">
          <a
            href="#home"
            className="text-[#f0f4ff] hover:text-[#a78bfa] transition-colors relative group"
            style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
          >
            Home
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-[#8b5cf6] to-[#a78bfa] group-hover:w-full transition-all duration-300" />
          </a>
          <a
            href="#features"
            className="text-[#b8c1ec] hover:text-[#f0f4ff] transition-colors relative group"
            style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
          >
            Features
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-[#8b5cf6] to-[#a78bfa] group-hover:w-full transition-all duration-300" />
          </a>
          <button
            onClick={onLoginClick}
            className="text-[#b8c1ec] hover:text-[#f0f4ff] transition-colors relative group"
            style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
          >
            Login
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-[#8b5cf6] to-[#a78bfa] group-hover:w-full transition-all duration-300" />
          </button>
          <motion.button
            onClick={onSignUpClick}
            className="group relative px-7 py-3 bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] rounded-lg overflow-hidden shadow-[0_0_30px_rgba(139,92,246,0.25)]"
            style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
            whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(139, 92, 246, 0.5)' }}
            whileTap={{ scale: 0.98 }}
            transition={{ duration: 0.2 }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#a78bfa] to-[#818cf8] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <span className="relative z-10 text-white">Sign Up</span>
          </motion.button>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-[#f0f4ff] hover:text-[#a78bfa] transition-colors">
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
        </button>
      </div>
    </motion.nav>
  );
}
