import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Eye, EyeOff, Sparkles, Mail, Lock, User } from 'lucide-react';

interface SignUpOverlayProps {
  onClose: () => void;
  onSwitchToLogin?: () => void;
  onSuccess?: () => void;
}

export default function SignUpOverlay({ onClose, onSwitchToLogin, onSuccess }: SignUpOverlayProps) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock sign up - in real app, this would call an API
    if (onSuccess) {
      onSuccess();
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        {/* Darkened background overlay - keeps landing page visible but muted */}
        <motion.div
          className="absolute inset-0 bg-[#0a0a0f]/85 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        />

        {/* Sign up content container - slides in from right */}
        <motion.div
          className="relative z-10 w-full max-w-[1400px] mx-auto px-6 grid lg:grid-cols-2 gap-16 lg:gap-24 items-center"
          initial={{ opacity: 0, x: 60 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 60 }}
          transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
        >

          {/* Left side - Join olYmpos branding */}
          <div className="hidden lg:block">
            {/* Badge */}
            <motion.div
              className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full border border-[#8b5cf6]/60 bg-gradient-to-r from-[#8b5cf6]/30 to-[#6366f1]/25 backdrop-blur-md mb-8 shadow-[0_0_30px_rgba(139,92,246,0.3)]"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Sparkles className="w-4 h-4 text-[#a78bfa]" />
              <span className="text-sm tracking-wider text-[#e9d5ff]" style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                Join olYmpos
              </span>
            </motion.div>

            {/* Heading */}
            <motion.h1
              className="text-5xl lg:text-6xl xl:text-7xl mb-6 tracking-tight leading-[1.1]"
              style={{ fontFamily: 'var(--font-display)' }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <span className="bg-gradient-to-br from-[#f0f4ff] via-[#d4c5f9] to-[#c4b5fd] bg-clip-text text-transparent">
                START YOUR
              </span>
              <br />
              <span className="bg-gradient-to-br from-[#c4b5fd] via-[#a78bfa] to-[#8b5cf6] bg-clip-text text-transparent">
                UNIVERSE
              </span>
            </motion.h1>

            {/* Subtext */}
            <motion.p
              className="text-lg lg:text-xl text-[#b8c1ec] leading-relaxed max-w-md"
              style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              Track your anime, movies, and games in one place.
            </motion.p>
          </div>

          {/* Right side - Sign up card */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2, ease: [0.25, 0.1, 0.25, 1] }}
          >
            {/* Card glow effect */}
            <div className="absolute -inset-1 bg-gradient-to-br from-[#8b5cf6] via-[#7c3aed] to-[#6366f1] rounded-3xl blur-2xl opacity-25" />

            {/* Sign up card */}
            <div className="relative bg-gradient-to-br from-[#1a1a2e]/98 via-[#16162a]/98 to-[#1a1a2e]/98 backdrop-blur-xl rounded-3xl border border-[#8b5cf6]/40 p-10 lg:p-12 shadow-[0_20px_80px_rgba(0,0,0,0.6)] overflow-hidden">
              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-5 right-5 p-2 rounded-full hover:bg-white/10 transition-colors z-20"
                aria-label="Close"
              >
                <X className="w-5 h-5 text-white/70 hover:text-white" />
              </button>

              {/* Top accent glow */}
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#8b5cf6] to-transparent opacity-80" />
              <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-[#8b5cf6]/10 to-transparent pointer-events-none" />

              {/* Card header */}
              <div className="mb-9">
                <h2
                  className="text-3xl lg:text-4xl mb-3.5 tracking-tight"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  <span className="bg-gradient-to-br from-[#f0f4ff] via-[#e9d5ff] to-[#c4b5fd] bg-clip-text text-transparent">
                    Sign Up
                  </span>
                </h2>
                <p
                  className="text-[#b8c1ec] text-sm lg:text-base leading-relaxed"
                  style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                >
                  Create your account and start building your olYmpos.
                </p>
              </div>

              {/* Form */}
              <form className="space-y-6" onSubmit={handleSubmit}>
                {/* Username field */}
                <div>
                  <label
                    htmlFor="username"
                    className="block text-sm mb-2.5 text-[#e9d5ff]"
                    style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                  >
                    Username
                  </label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8b5cf6]/60" />
                    <input
                      id="username"
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="Choose a username"
                      className="w-full pl-12 pr-5 py-4 bg-[#0a0a0f]/70 border border-[#8b5cf6]/30 rounded-xl text-white placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/60 focus:border-[#8b5cf6] transition-all shadow-[0_4px_20px_rgba(0,0,0,0.2)]"
                      style={{ fontFamily: 'var(--font-body)' }}
                    />
                  </div>
                </div>

                {/* Email field */}
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm mb-2.5 text-[#e9d5ff]"
                    style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                  >
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8b5cf6]/60" />
                    <input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      className="w-full pl-12 pr-5 py-4 bg-[#0a0a0f]/70 border border-[#8b5cf6]/30 rounded-xl text-white placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/60 focus:border-[#8b5cf6] transition-all shadow-[0_4px_20px_rgba(0,0,0,0.2)]"
                      style={{ fontFamily: 'var(--font-body)' }}
                    />
                  </div>
                </div>

                {/* Password field */}
                <div>
                  <label
                    htmlFor="password"
                    className="block text-sm mb-2.5 text-[#e9d5ff]"
                    style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                  >
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8b5cf6]/60" />
                    <input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Create a password"
                      className="w-full pl-12 pr-12 py-4 bg-[#0a0a0f]/70 border border-[#8b5cf6]/30 rounded-xl text-white placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/60 focus:border-[#8b5cf6] transition-all shadow-[0_4px_20px_rgba(0,0,0,0.2)]"
                      style={{ fontFamily: 'var(--font-body)' }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-[#8b5cf6] hover:text-[#a78bfa] transition-colors"
                    >
                      {showPassword ? (
                        <EyeOff className="w-5 h-5" />
                      ) : (
                        <Eye className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Confirm Password field */}
                <div>
                  <label
                    htmlFor="confirmPassword"
                    className="block text-sm mb-2.5 text-[#e9d5ff]"
                    style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                  >
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8b5cf6]/60" />
                    <input
                      id="confirmPassword"
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm your password"
                      className="w-full pl-12 pr-12 py-4 bg-[#0a0a0f]/70 border border-[#8b5cf6]/30 rounded-xl text-white placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/60 focus:border-[#8b5cf6] transition-all shadow-[0_4px_20px_rgba(0,0,0,0.2)]"
                      style={{ fontFamily: 'var(--font-body)' }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-[#8b5cf6] hover:text-[#a78bfa] transition-colors"
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="w-5 h-5" />
                      ) : (
                        <Eye className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Create Account button */}
                <button
                  type="submit"
                  className="w-full group relative px-8 py-4 bg-gradient-to-br from-[#8b5cf6] via-[#7c3aed] to-[#6366f1] rounded-xl overflow-hidden transition-all hover:scale-[1.02] shadow-[0_0_50px_rgba(139,92,246,0.6)] hover:shadow-[0_0_70px_rgba(139,92,246,0.9)] mt-2"
                  style={{ fontFamily: 'var(--font-body)' }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-[#a78bfa] via-[#9333ea] to-[#818cf8] opacity-0 group-hover:opacity-100 transition-all duration-300" />
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.3),transparent_50%)]" />
                  </div>
                  <span className="relative z-10 font-semibold text-lg text-white tracking-wide">Create Account</span>
                </button>

                {/* Login link */}
                <p
                  className="text-center text-sm text-[#b8c1ec] mt-7"
                  style={{ fontFamily: 'var(--font-body)' }}
                >
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={onSwitchToLogin}
                    className="text-[#8b5cf6] hover:text-[#a78bfa] hover:underline font-medium transition-all"
                  >
                    Login
                  </button>
                </p>
              </form>
            </div>
          </motion.div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}