import { motion, AnimatePresence } from 'motion/react';
import { X, Star, Heart, Tv, Film, Gamepad2, Save, Play, TrendingUp, Clock, Edit2 } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';

interface EditEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  item?: {
    title: string;
    category: 'Anime' | 'Movie' | 'Game';
    image: string;
  };
}

export function EditEntryModal({ isOpen, onClose, item }: EditEntryModalProps) {
  const [status, setStatus] = useState('Watching');
  const [rating, setRating] = useState(5);
  const [isFavorite, setIsFavorite] = useState(true);
  const [season, setSeason] = useState('3');
  const [episode, setEpisode] = useState('18');
  const [review, setReview] = useState('An absolute masterpiece that redefined the shounen genre. The plot twists are incredible, and the character development is phenomenal.');

  const categoryIcon = {
    Anime: Tv,
    Movie: Film,
    Game: Gamepad2,
  }[item?.category || 'Anime'];

  const CategoryIcon = categoryIcon;

  const statusOptions = ['Planned', 'Watching', 'Completed', 'Paused', 'Dropped'];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-[#0a0a0f]/90 backdrop-blur-md z-[100]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Modal Container */}
          <div className="fixed inset-0 z-[101] flex items-center justify-center p-4 overflow-y-auto">
            <motion.div
              className="w-full max-w-2xl my-8"
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
            >
              {/* Modal Card */}
              <div className="relative rounded-2xl bg-gradient-to-br from-[#1a1a2e] to-[#16162a] border border-[#8b5cf6]/30 shadow-2xl overflow-hidden">
                {/* Glow Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#8b5cf6]/10 via-transparent to-[#6366f1]/10 pointer-events-none" />
                
                {/* Close Button */}
                <button
                  onClick={onClose}
                  className="absolute top-6 right-6 p-2 rounded-xl bg-[#0a0a0f]/60 hover:bg-[#0a0a0f]/80 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all z-10"
                >
                  <X className="w-5 h-5 text-[#b8c1ec]" />
                </button>

                {/* Modal Content */}
                <div className="relative p-8">
                  {/* Header */}
                  <div className="mb-8">
                    <h2
                      className="text-3xl mb-2 bg-gradient-to-br from-[#f0f4ff] via-[#d4c5f9] to-[#c4b5fd] bg-clip-text text-transparent"
                      style={{ fontFamily: 'var(--font-display)' }}
                    >
                      Edit Entry
                    </h2>
                    <p
                      className="text-[#b8c1ec]"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                    >
                      Update your tracking details and review
                    </p>
                  </div>

                  {/* Item Preview */}
                  <div className="flex items-center gap-4 mb-8 p-4 rounded-xl bg-[#0a0a0f]/40 border border-[#8b5cf6]/20">
                    <div className="relative w-16 h-20 rounded-lg overflow-hidden flex-shrink-0">
                      <ImageWithFallback
                        src={item?.image || 'https://images.unsplash.com/photo-1764520408437-95890a95db4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmltZSUyMGNoYXJhY3RlciUyMHBvc3l0ZXJ8ZW58MHwxfHx8fDE3NzYyMDkwNjN8MA&ixlib=rb-4.1.0&q=80&w=1080'}
                        alt={item?.title || 'Attack on Titan'}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3
                        className="text-xl mb-1 text-[#f0f4ff] truncate"
                        style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                      >
                        {item?.title || 'Attack on Titan'}
                      </h3>
                      <div className="flex items-center gap-2">
                        <CategoryIcon className="w-4 h-4 text-[#8b5cf6]" />
                        <span
                          className="text-sm text-[#8b5cf6]"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                        >
                          {item?.category || 'Anime'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Form Fields */}
                  <div className="space-y-6">
                    {/* Status and Favorite Row */}
                    <div className="grid sm:grid-cols-2 gap-6">
                      {/* Status */}
                      <div>
                        <label
                          className="flex items-center gap-2 text-sm text-[#b8c1ec] mb-3"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                        >
                          <Play className="w-4 h-4 text-[#8b5cf6]" />
                          Status
                        </label>
                        <div className="space-y-2">
                          {statusOptions.map((option) => (
                            <button
                              key={option}
                              onClick={() => setStatus(option)}
                              className={`w-full px-4 py-3 rounded-xl border transition-all text-left ${
                                status === option
                                  ? 'bg-[#8b5cf6]/20 border-[#8b5cf6]/60 text-[#c4b5fd]'
                                  : 'bg-[#0a0a0f]/40 border-[#8b5cf6]/20 text-[#b8c1ec] hover:border-[#8b5cf6]/40'
                              }`}
                            >
                              <span
                                className="text-sm font-medium"
                                style={{ fontFamily: 'var(--font-body)' }}
                              >
                                {option}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Rating and Favorite */}
                      <div className="space-y-6">
                        {/* Rating */}
                        <div>
                          <label
                            className="flex items-center gap-2 text-sm text-[#b8c1ec] mb-3"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                          >
                            <Star className="w-4 h-4 text-[#8b5cf6]" />
                            Your Rating
                          </label>
                          <div className="p-4 rounded-xl bg-[#0a0a0f]/40 border border-[#8b5cf6]/20">
                            <div className="flex items-center justify-center gap-2 mb-3">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <button
                                  key={star}
                                  onClick={() => setRating(star)}
                                  className="transition-transform hover:scale-110"
                                >
                                  <Star
                                    className={`w-7 h-7 ${
                                      star <= rating
                                        ? 'fill-[#fbbf24] text-[#fbbf24]'
                                        : 'text-[#6b7280]'
                                    }`}
                                  />
                                </button>
                              ))}
                            </div>
                            <div className="text-center">
                              <span
                                className="text-2xl font-bold text-[#f0f4ff]"
                                style={{ fontFamily: 'var(--font-display)' }}
                              >
                                {rating * 2}
                              </span>
                              <span
                                className="text-sm text-[#b8c1ec] ml-1"
                                style={{ fontFamily: 'var(--font-body)' }}
                              >
                                / 10
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Favorite Toggle */}
                        <div>
                          <label
                            className="block text-sm text-[#b8c1ec] mb-3"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                          >
                            Favorite
                          </label>
                          <button
                            onClick={() => setIsFavorite(!isFavorite)}
                            className={`w-full px-4 py-3 rounded-xl border transition-all flex items-center justify-center gap-2 ${
                              isFavorite
                                ? 'bg-[#8b5cf6]/20 border-[#8b5cf6]/60'
                                : 'bg-[#0a0a0f]/40 border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40'
                            }`}
                          >
                            <Heart
                              className={`w-5 h-5 ${
                                isFavorite
                                  ? 'fill-[#8b5cf6] text-[#8b5cf6]'
                                  : 'text-[#b8c1ec]'
                              }`}
                            />
                            <span
                              className={`text-sm font-semibold ${
                                isFavorite ? 'text-[#c4b5fd]' : 'text-[#b8c1ec]'
                              }`}
                              style={{ fontFamily: 'var(--font-body)' }}
                            >
                              {isFavorite ? 'Added to Favorites' : 'Add to Favorites'}
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Progress */}
                    <div>
                      <label
                        className="flex items-center gap-2 text-sm text-[#b8c1ec] mb-3"
                        style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                      >
                        <TrendingUp className="w-4 h-4 text-[#8b5cf6]" />
                        Progress
                      </label>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label
                            className="block text-xs text-[#8b5cf6] mb-2"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                          >
                            Season
                          </label>
                          <input
                            type="text"
                            value={season}
                            onChange={(e) => setSeason(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl bg-[#0a0a0f]/40 border border-[#8b5cf6]/20 text-[#f0f4ff] placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/40 focus:border-[#8b5cf6] transition-all"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                            placeholder="3"
                          />
                        </div>
                        <div>
                          <label
                            className="block text-xs text-[#8b5cf6] mb-2"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                          >
                            Episode
                          </label>
                          <input
                            type="text"
                            value={episode}
                            onChange={(e) => setEpisode(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl bg-[#0a0a0f]/40 border border-[#8b5cf6]/20 text-[#f0f4ff] placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/40 focus:border-[#8b5cf6] transition-all"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                            placeholder="18"
                          />
                        </div>
                      </div>
                      <div className="mt-3 text-center">
                        <span
                          className="text-xs text-[#8b5cf6]"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                        >
                          Currently on Season {season}, Episode {episode}
                        </span>
                      </div>
                    </div>

                    {/* Personal Review */}
                    <div>
                      <label
                        className="flex items-center gap-2 text-sm text-[#b8c1ec] mb-3"
                        style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                      >
                        <Edit2 className="w-4 h-4 text-[#8b5cf6]" />
                        Personal Review / Notes
                      </label>
                      <textarea
                        value={review}
                        onChange={(e) => setReview(e.target.value)}
                        rows={5}
                        className="w-full px-4 py-3 rounded-xl bg-[#0a0a0f]/40 border border-[#8b5cf6]/20 text-[#f0f4ff] placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/40 focus:border-[#8b5cf6] transition-all resize-none"
                        style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                        placeholder="Share your thoughts about this anime..."
                      />
                      <div className="mt-2 text-right">
                        <span
                          className="text-xs text-[#6b7280]"
                          style={{ fontFamily: 'var(--font-body)' }}
                        >
                          {review.length} characters
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-4 mt-8 pt-6 border-t border-[#8b5cf6]/10">
                    <button
                      onClick={onClose}
                      className="flex-1 px-6 py-3.5 rounded-xl border border-[#8b5cf6]/40 hover:bg-[#8b5cf6]/10 transition-all text-[#b8c1ec] hover:text-[#e9d5ff]"
                    >
                      <span
                        className="text-sm font-semibold"
                        style={{ fontFamily: 'var(--font-body)' }}
                      >
                        Cancel
                      </span>
                    </button>
                    <button className="flex-1 flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] hover:from-[#a78bfa] hover:to-[#818cf8] transition-all shadow-lg text-white">
                      <Save className="w-4 h-4" />
                      <span
                        className="text-sm font-semibold"
                        style={{ fontFamily: 'var(--font-body)' }}
                      >
                        Save Changes
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}