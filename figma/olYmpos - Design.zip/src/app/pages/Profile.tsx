import { motion } from 'motion/react';
import { Search, Bell, Settings, Tv, Film, Gamepad2, Star, LogOut, Zap, Sparkles, Edit, Lock, Globe, Clock, TrendingUp, Award } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function Profile() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white antialiased">
      {/* Cosmic Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f1729] via-[#0a0a0f] to-[#0a0a0f]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(139,92,246,0.06),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_30%,rgba(99,102,241,0.04),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(10,10,15,0.3)_100%)]" />
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Top Navigation - same as Dashboard/Library */}
        <nav className="border-b border-[#8b5cf6]/10 bg-[#0a0a0f]/80 backdrop-blur-xl sticky top-0 z-50">
          <div className="max-w-[1600px] mx-auto px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              {/* Logo with Icon */}
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Zap className="w-7 h-7 text-[#8b5cf6] fill-[#8b5cf6] relative z-10" />
                  <motion.div
                    className="absolute inset-0 blur-lg bg-[#8b5cf6] opacity-40"
                    animate={{
                      opacity: [0.4, 0.6, 0.4],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                  />
                </div>
                <h1
                  className="text-2xl tracking-tight bg-gradient-to-br from-[#f0f4ff] via-[#c4b5fd] to-[#a78bfa] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  olYmpos
                </h1>
              </div>

              {/* Right Side with Search and Profile */}
              <div className="flex items-center gap-6">
                {/* Search Bar */}
                <div className="hidden md:block">
                  <div className="relative w-[320px]">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8b5cf6]/50" />
                    <input
                      type="text"
                      placeholder="Search anime, movies, games..."
                      className="w-full pl-12 pr-5 py-2.5 bg-[#1a1a2e]/60 border border-[#8b5cf6]/20 rounded-xl text-white placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/40 focus:border-[#8b5cf6] transition-all text-sm"
                      style={{ fontFamily: 'var(--font-body)' }}
                    />
                  </div>
                </div>

                {/* Notification */}
                <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors relative">
                  <Bell className="w-5 h-5 text-[#b8c1ec]" />
                  <span className="absolute top-2 right-2 w-2 h-2 bg-[#8b5cf6] rounded-full" />
                </button>

                {/* Settings */}
                <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors">
                  <Settings className="w-5 h-5 text-[#b8c1ec]" />
                </button>

                {/* Profile Avatar */}
                <div className="flex items-center gap-3 pl-3 pr-4 py-2 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#6366f1]/20 border border-[#8b5cf6]/30 cursor-pointer hover:from-[#8b5cf6]/30 hover:to-[#6366f1]/30 transition-all">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#6366f1] flex items-center justify-center">
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      JD
                    </span>
                  </div>
                  <span className="text-sm text-[#e9d5ff] font-medium hidden lg:block" style={{ fontFamily: 'var(--font-body)' }}>
                    John Doe
                  </span>
                </div>

                {/* Sign Out Button */}
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 hover:bg-[#8b5cf6]/10 transition-all text-[#b8c1ec] hover:text-[#e9d5ff]">
                  <LogOut className="w-4 h-4" />
                  <span className="text-sm font-medium hidden xl:block" style={{ fontFamily: 'var(--font-body)' }}>
                    Sign Out
                  </span>
                </button>
              </div>
            </div>
          </div>
        </nav>

        {/* Profile Content */}
        <main className="max-w-[1400px] mx-auto px-6 lg:px-8 py-12">
          {/* Page Header */}
          <motion.div
            className="mb-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative mb-3">
              {/* Decorative sparkle accent behind heading */}
              <Sparkles className="absolute -left-3 top-1/2 -translate-y-1/2 w-16 h-16 text-[#8b5cf6] opacity-[0.08] -z-10" />
              <h2
                className="text-4xl lg:text-5xl tracking-tight bg-gradient-to-br from-[#f0f4ff] via-[#d4c5f9] to-[#c4b5fd] bg-clip-text text-transparent"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Profile
              </h2>
            </div>
          </motion.div>

          {/* Profile Header Section */}
          <motion.div
            className="mb-12 p-8 lg:p-10 rounded-2xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <div className="flex flex-col lg:flex-row items-start gap-8">
              {/* Avatar */}
              <div className="relative">
                <div className="w-32 h-32 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#6366f1] flex items-center justify-center shadow-lg">
                  <span className="text-5xl font-bold" style={{ fontFamily: 'var(--font-body)' }}>
                    JD
                  </span>
                </div>
                <div className="absolute -bottom-2 -right-2 p-2 rounded-lg bg-[#8b5cf6] border-2 border-[#0a0a0f]">
                  <Award className="w-5 h-5 text-white" />
                </div>
              </div>

              {/* Profile Info */}
              <div className="flex-1">
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div>
                    <h3
                      className="text-3xl mb-2 bg-gradient-to-r from-[#f0f4ff] to-[#c4b5fd] bg-clip-text text-transparent"
                      style={{ fontFamily: 'var(--font-display)' }}
                    >
                      John Doe
                    </h3>
                    <div className="flex items-center gap-2 mb-3">
                      <Globe className="w-4 h-4 text-[#8b5cf6]" />
                      <span
                        className="text-sm text-[#a78bfa]"
                        style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                      >
                        Public Profile
                      </span>
                    </div>
                  </div>
                  <button className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] hover:from-[#a78bfa] hover:to-[#818cf8] transition-all shadow-lg text-white">
                    <Edit className="w-4 h-4" />
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      Edit Profile
                    </span>
                  </button>
                </div>

                <p
                  className="text-[#b8c1ec] mb-4 max-w-2xl"
                  style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                >
                  Entertainment enthusiast tracking anime, movies, and games. Building my ultimate watchlist in the olYmpos universe.
                </p>

                {/* Tags */}
                <div className="flex items-center gap-2 flex-wrap">
                  {['Anime Fan', 'Sci-Fi Lover', 'RPG Gamer'].map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1.5 rounded-lg bg-[#8b5cf6]/20 text-[#a78bfa] border border-[#8b5cf6]/30 text-sm"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Stats Section */}
          <motion.div
            className="grid sm:grid-cols-3 gap-6 mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {[
              { label: 'Anime Tracked', value: '24', icon: Tv, color: 'from-[#8b5cf6] to-[#6366f1]' },
              { label: 'Movies Tracked', value: '18', icon: Film, color: 'from-[#6366f1] to-[#4f46e5]' },
              { label: 'Games Tracked', value: '12', icon: Gamepad2, color: 'from-[#4f46e5] to-[#8b5cf6]' },
            ].map((stat) => (
              <div
                key={stat.label}
                className="p-6 rounded-2xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all"
              >
                <div className="flex items-center gap-4 mb-3">
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${stat.color}`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <span
                    className="text-4xl font-bold bg-gradient-to-br from-[#f0f4ff] to-[#a78bfa] bg-clip-text text-transparent"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    {stat.value}
                  </span>
                </div>
                <p
                  className="text-[#b8c1ec]"
                  style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                >
                  {stat.label}
                </p>
              </div>
            ))}
          </motion.div>

          {/* Main Profile Content */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Left Column */}
            <div className="space-y-8">
              {/* Favorites Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <h3
                  className="text-2xl mb-6 flex items-center gap-2"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  <Star className="w-6 h-6 text-[#8b5cf6] fill-[#8b5cf6]" />
                  <span className="bg-gradient-to-r from-[#f0f4ff] to-[#c4b5fd] bg-clip-text text-transparent">
                    Favorites
                  </span>
                </h3>

                <div className="space-y-4">
                  {[
                    {
                      title: 'Attack on Titan',
                      category: 'Anime',
                      icon: Tv,
                      image: 'https://images.unsplash.com/photo-1764520408437-95890a95db4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmltZSUyMGNoYXJhY3RlciUyMHBvc3RlcnxlbnwxfHx8fDE3NzYyMDkwNjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
                    },
                    {
                      title: 'Inception',
                      category: 'Movie',
                      icon: Film,
                      image: 'https://images.unsplash.com/photo-1563202221-f4eae97e4828?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWF0aWMlMjBtb3ZpZSUyMHNjZW5lfGVufDF8fHx8MTc3NjIwOTA2M3ww&ixlib=rb-4.1.0&q=80&w=1080',
                    },
                    {
                      title: 'Elden Ring',
                      category: 'Game',
                      icon: Gamepad2,
                      image: 'https://images.unsplash.com/photo-1634658340808-9abaef7eb9a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2ktZmklMjB2aWRlbyUyMGdhbWUlMjBhcnR8ZW58MXx8fHwxNzc2MjA5MDY0fDA&ixlib=rb-4.1.0&q=80&w=1080',
                    },
                  ].map((favorite) => (
                    <div
                      key={favorite.title}
                      className="flex items-center gap-4 p-4 rounded-xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all cursor-pointer group"
                    >
                      <div className="relative w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                        <ImageWithFallback
                          src={favorite.image}
                          alt={favorite.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4
                          className="text-lg mb-1 text-[#f0f4ff] truncate"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                        >
                          {favorite.title}
                        </h4>
                        <div className="flex items-center gap-2">
                          <favorite.icon className="w-4 h-4 text-[#8b5cf6]" />
                          <span
                            className="text-sm text-[#b8c1ec]"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                          >
                            {favorite.category}
                          </span>
                        </div>
                      </div>
                      <Star className="w-5 h-5 text-[#fbbf24] fill-[#fbbf24] flex-shrink-0" />
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Activity Summary Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <h3
                  className="text-2xl mb-6 flex items-center gap-2"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  <TrendingUp className="w-6 h-6 text-[#8b5cf6]" />
                  <span className="bg-gradient-to-r from-[#f0f4ff] to-[#c4b5fd] bg-clip-text text-transparent">
                    Activity Summary
                  </span>
                </h3>

                <div className="space-y-3">
                  {[
                    { label: 'Completed', value: 28, color: 'bg-green-500' },
                    { label: 'Watching / Playing', value: 12, color: 'bg-[#8b5cf6]' },
                    { label: 'Planned', value: 14, color: 'bg-blue-500' },
                  ].map((activity) => (
                    <div
                      key={activity.label}
                      className="p-4 rounded-xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span
                          className="text-[#b8c1ec]"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                        >
                          {activity.label}
                        </span>
                        <span
                          className="text-xl font-bold text-[#f0f4ff]"
                          style={{ fontFamily: 'var(--font-display)' }}
                        >
                          {activity.value}
                        </span>
                      </div>
                      <div className="h-2 bg-[#1a1a2e] rounded-full overflow-hidden">
                        <div
                          className={`h-full ${activity.color} rounded-full transition-all duration-500`}
                          style={{ width: `${(activity.value / 54) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Right Column */}
            <div className="space-y-8">
              {/* Recent Reviews Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                <h3
                  className="text-2xl mb-6 flex items-center gap-2"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  <Star className="w-6 h-6 text-[#8b5cf6]" />
                  <span className="bg-gradient-to-r from-[#f0f4ff] to-[#c4b5fd] bg-clip-text text-transparent">
                    Recent Reviews
                  </span>
                </h3>

                <div className="space-y-4">
                  {[
                    {
                      title: 'The Last of Us Part II',
                      rating: 5,
                      review: 'An emotional masterpiece with stunning visuals and deep storytelling. One of the best games I\'ve ever played.',
                      date: '2 days ago',
                    },
                    {
                      title: 'Your Name',
                      rating: 5,
                      review: 'Beautiful animation and a heartfelt story that stays with you long after watching.',
                      date: '5 days ago',
                    },
                  ].map((review) => (
                    <div
                      key={review.title}
                      className="p-5 rounded-xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <h4
                          className="text-lg text-[#f0f4ff]"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                        >
                          {review.title}
                        </h4>
                        <div className="flex items-center gap-1">
                          {[...Array(review.rating)].map((_, i) => (
                            <Star key={i} className="w-4 h-4 fill-[#fbbf24] text-[#fbbf24]" />
                          ))}
                        </div>
                      </div>
                      <p
                        className="text-[#b8c1ec] mb-3 text-sm leading-relaxed"
                        style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                      >
                        {review.review}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-[#8b5cf6]">
                        <Clock className="w-3.5 h-3.5" />
                        <span style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                          {review.date}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Recently Tracked Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <h3
                  className="text-2xl mb-6 flex items-center gap-2"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  <Clock className="w-6 h-6 text-[#8b5cf6]" />
                  <span className="bg-gradient-to-r from-[#f0f4ff] to-[#c4b5fd] bg-clip-text text-transparent">
                    Recently Tracked
                  </span>
                </h3>

                <div className="space-y-3">
                  {[
                    {
                      title: 'Demon Slayer',
                      category: 'Anime',
                      icon: Tv,
                      status: 'Watching',
                      progress: 'S2 E8',
                    },
                    {
                      title: 'God of War',
                      category: 'Game',
                      icon: Gamepad2,
                      status: 'Playing',
                      progress: '45%',
                    },
                    {
                      title: 'The Matrix',
                      category: 'Movie',
                      icon: Film,
                      status: 'Completed',
                      progress: null,
                    },
                  ].map((item) => (
                    <div
                      key={item.title}
                      className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-[#8b5cf6]/20">
                          <item.icon className="w-5 h-5 text-[#8b5cf6]" />
                        </div>
                        <div>
                          <h4
                            className="text-[#f0f4ff] mb-1"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                          >
                            {item.title}
                          </h4>
                          <span
                            className="text-xs text-[#b8c1ec]"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                          >
                            {item.category}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div
                          className="text-sm text-[#a78bfa] mb-1"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                        >
                          {item.status}
                        </div>
                        {item.progress && (
                          <div
                            className="text-xs text-[#b8c1ec]"
                            style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                          >
                            {item.progress}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
