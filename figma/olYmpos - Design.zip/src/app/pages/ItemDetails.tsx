import { motion } from 'motion/react';
import { Search, Bell, Settings, Tv, Film, Gamepad2, Star, LogOut, Zap, Edit, ChevronRight, Calendar, Award, TrendingUp, Clock, Heart, Play, Check, Bookmark, Share2, Plus } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { EditEntryModal } from '../components/EditEntryModal';
import { useState } from 'react';

export default function ItemDetails() {
  const [isModalOpen, setIsModalOpen] = useState(true);

  const itemData = {
    title: 'Attack on Titan',
    category: 'Anime' as const,
    image: 'https://images.unsplash.com/photo-1764520408437-95890a95db4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmltZSUyMGNoYXJhY3RlciUyMHBvc3RlcnxlbnwxfHx8fDE3NzYyMDkwNjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white antialiased">
      {/* Cosmic Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f1729] via-[#0a0a0f] to-[#0a0a0f]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(139,92,246,0.06),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_30%,rgba(99,102,241,0.04),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(10,10,15,0.3)_100%)]" />
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Top Navigation - same as other pages */}
        <nav className="border-b border-[#8b5cf6]/10 bg-[#0a0a0f]/80 backdrop-blur-xl sticky top-0 z-50">
          <div className="max-w-[1600px] mx-auto px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              {/* Logo with Icon */}
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Zap className="w-7 h-7 text-[#8b5cf6] fill-[#8b5cf6] relative z-10" />
                  <motion.div
                    className="absolute inset-0 blur-lg bg-[#8b5cf6] opacity-40"
                    animate={{
                      opacity: [0.4, 0.6, 0.4],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                  />
                </div>
                <h1
                  className="text-2xl tracking-tight bg-gradient-to-br from-[#f0f4ff] via-[#c4b5fd] to-[#a78bfa] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  olYmpos
                </h1>
              </div>

              {/* Right Side with Search and Profile */}
              <div className="flex items-center gap-6">
                {/* Search Bar */}
                <div className="hidden md:block">
                  <div className="relative w-[320px]">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8b5cf6]/50" />
                    <input
                      type="text"
                      placeholder="Search anime, movies, games..."
                      className="w-full pl-12 pr-5 py-2.5 bg-[#1a1a2e]/60 border border-[#8b5cf6]/20 rounded-xl text-white placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/40 focus:border-[#8b5cf6] transition-all text-sm"
                      style={{ fontFamily: 'var(--font-body)' }}
                    />
                  </div>
                </div>

                {/* Notification */}
                <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors relative">
                  <Bell className="w-5 h-5 text-[#b8c1ec]" />
                  <span className="absolute top-2 right-2 w-2 h-2 bg-[#8b5cf6] rounded-full" />
                </button>

                {/* Settings */}
                <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors">
                  <Settings className="w-5 h-5 text-[#b8c1ec]" />
                </button>

                {/* Profile Avatar */}
                <div className="flex items-center gap-3 pl-3 pr-4 py-2 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#6366f1]/20 border border-[#8b5cf6]/30 cursor-pointer hover:from-[#8b5cf6]/30 hover:to-[#6366f1]/30 transition-all">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#6366f1] flex items-center justify-center">
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      JD
                    </span>
                  </div>
                  <span className="text-sm text-[#e9d5ff] font-medium hidden lg:block" style={{ fontFamily: 'var(--font-body)' }}>
                    John Doe
                  </span>
                </div>

                {/* Sign Out Button */}
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 hover:bg-[#8b5cf6]/10 transition-all text-[#b8c1ec] hover:text-[#e9d5ff]">
                  <LogOut className="w-4 h-4" />
                  <span className="text-sm font-medium hidden xl:block" style={{ fontFamily: 'var(--font-body)' }}>
                    Sign Out
                  </span>
                </button>
              </div>
            </div>
          </div>
        </nav>

        {/* Item Details Content */}
        <main className="max-w-[1600px] mx-auto px-6 lg:px-8 py-8">
          {/* Breadcrumb Navigation */}
          <motion.div
            className="flex items-center gap-2 mb-8 text-sm"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <button
              className="text-[#8b5cf6] hover:text-[#a78bfa] transition-colors"
              style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
            >
              Library
            </button>
            <ChevronRight className="w-4 h-4 text-[#6b7280]" />
            <button
              className="text-[#8b5cf6] hover:text-[#a78bfa] transition-colors"
              style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
            >
              Anime
            </button>
            <ChevronRight className="w-4 h-4 text-[#6b7280]" />
            <span
              className="text-[#b8c1ec]"
              style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
            >
              Attack on Titan
            </span>
          </motion.div>

          {/* Hero Section */}
          <motion.div
            className="mb-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Poster Image */}
              <div className="lg:w-[320px] flex-shrink-0">
                <div className="relative rounded-2xl overflow-hidden border border-[#8b5cf6]/30 shadow-2xl group">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1764520408437-95890a95db4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmltZSUyMGNoYXJhY3RlciUyMHBvc3RlcnxlbnwxfHx8fDE3NzYyMDkwNjN8MA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Attack on Titan"
                    className="w-full aspect-[2/3] object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {/* Favorite Badge */}
                  <div className="absolute top-4 right-4">
                    <button className="p-3 rounded-full bg-[#0a0a0f]/80 backdrop-blur-sm border border-[#8b5cf6]/30 hover:bg-[#8b5cf6]/20 transition-all">
                      <Heart className="w-5 h-5 text-[#8b5cf6] fill-[#8b5cf6]" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Details */}
              <div className="flex-1">
                {/* Title and Category */}
                <div className="mb-6">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#8b5cf6]/30 to-[#6366f1]/30 border border-[#8b5cf6]/40 text-[#c4b5fd] text-sm flex items-center gap-2" style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>
                      <Tv className="w-4 h-4" />
                      Anime
                    </span>
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 fill-[#fbbf24] text-[#fbbf24]" />
                      <span className="text-xl font-bold text-[#f0f4ff]" style={{ fontFamily: 'var(--font-display)' }}>
                        9.1
                      </span>
                      <span className="text-sm text-[#b8c1ec]" style={{ fontFamily: 'var(--font-body)' }}>
                        / 10
                      </span>
                    </div>
                  </div>
                  
                  <h1
                    className="text-5xl lg:text-6xl mb-4 bg-gradient-to-br from-[#f0f4ff] via-[#d4c5f9] to-[#c4b5fd] bg-clip-text text-transparent leading-tight"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    Attack on Titan
                  </h1>

                  {/* Genres and Year */}
                  <div className="flex items-center gap-3 flex-wrap mb-4">
                    {['Action', 'Dark Fantasy', 'Drama', 'Mystery'].map((genre) => (
                      <span
                        key={genre}
                        className="px-3 py-1.5 rounded-lg bg-[#1a1a2e]/80 border border-[#8b5cf6]/20 text-[#b8c1ec] text-sm"
                        style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                      >
                        {genre}
                      </span>
                    ))}
                    <span className="flex items-center gap-2 text-[#8b5cf6]" style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                      <Calendar className="w-4 h-4" />
                      2013 - 2023
                    </span>
                  </div>
                </div>

                {/* Synopsis */}
                <div className="mb-8">
                  <h3
                    className="text-xl mb-3 text-[#f0f4ff]"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    Synopsis
                  </h3>
                  <p
                    className="text-[#b8c1ec] leading-relaxed max-w-3xl"
                    style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                  >
                    Humanity lives inside cities surrounded by enormous walls due to the Titans, gigantic humanoid creatures who devour humans seemingly without reason. The story follows Eren Yeager, who vows to exterminate the Titans after they bring about the destruction of his hometown and the death of his mother. As the series progresses, it explores themes of freedom, survival, and the cyclical nature of hatred.
                  </p>
                </div>

                {/* Quick Actions */}
                <div className="flex items-center gap-4 flex-wrap">
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] hover:from-[#a78bfa] hover:to-[#818cf8] transition-all shadow-lg text-white"
                  >
                    <Edit className="w-4 h-4" />
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      Edit Entry
                    </span>
                  </button>
                  
                  <button className="flex items-center gap-2 px-6 py-3 rounded-xl border border-[#8b5cf6]/40 hover:bg-[#8b5cf6]/10 transition-all text-[#b8c1ec] hover:text-[#e9d5ff]">
                    <Share2 className="w-4 h-4" />
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      Share
                    </span>
                  </button>

                  <button className="flex items-center gap-2 px-6 py-3 rounded-xl border border-[#8b5cf6]/40 hover:bg-[#8b5cf6]/10 transition-all text-[#b8c1ec] hover:text-[#e9d5ff]">
                    <Bookmark className="w-4 h-4" />
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      Add to List
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Main Content Grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left Column - Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Personal Tracking Section */}
              <motion.div
                className="p-8 rounded-2xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                <h3
                  className="text-2xl mb-6 flex items-center gap-2"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  <TrendingUp className="w-6 h-6 text-[#8b5cf6]" />
                  <span className="bg-gradient-to-r from-[#f0f4ff] to-[#c4b5fd] bg-clip-text text-transparent">
                    Your Tracking
                  </span>
                </h3>

                <div className="grid sm:grid-cols-2 gap-6 mb-6">
                  {/* Status */}
                  <div>
                    <label
                      className="block text-sm text-[#b8c1ec] mb-2"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                    >
                      Status
                    </label>
                    <div className="px-4 py-3 rounded-xl bg-[#8b5cf6]/20 border border-[#8b5cf6]/40 text-[#c4b5fd] flex items-center gap-2">
                      <Play className="w-4 h-4" />
                      <span style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>
                        Watching
                      </span>
                    </div>
                  </div>

                  {/* Your Rating */}
                  <div>
                    <label
                      className="block text-sm text-[#b8c1ec] mb-2"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                    >
                      Your Rating
                    </label>
                    <div className="px-4 py-3 rounded-xl bg-[#1a1a2e]/80 border border-[#8b5cf6]/20 flex items-center gap-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-[#fbbf24] text-[#fbbf24]" />
                      ))}
                      <span className="ml-2 text-[#f0f4ff] font-bold" style={{ fontFamily: 'var(--font-body)' }}>
                        10/10
                      </span>
                    </div>
                  </div>
                </div>

                {/* Progress */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <label
                      className="text-sm text-[#b8c1ec]"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                    >
                      Progress
                    </label>
                    <span
                      className="text-sm text-[#8b5cf6] font-bold"
                      style={{ fontFamily: 'var(--font-body)' }}
                    >
                      S3 E18 / S4 E28
                    </span>
                  </div>
                  <div className="h-3 bg-[#1a1a2e] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] rounded-full transition-all duration-500"
                      style={{ width: '65%' }}
                    />
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-[#b8c1ec]" style={{ fontFamily: 'var(--font-body)' }}>
                      Started: January 15, 2024
                    </span>
                    <span className="text-xs text-[#8b5cf6]" style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>
                      65% Complete
                    </span>
                  </div>
                </div>

                {/* Update Progress Button */}
                <button className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl border border-[#8b5cf6]/40 hover:bg-[#8b5cf6]/10 transition-all text-[#c4b5fd] hover:text-[#e9d5ff]">
                  <Plus className="w-4 h-4" />
                  <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                    Update Progress
                  </span>
                </button>
              </motion.div>

              {/* Personal Review */}
              <motion.div
                className="p-8 rounded-2xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h3
                  className="text-2xl mb-4 flex items-center gap-2"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  <Star className="w-6 h-6 text-[#8b5cf6]" />
                  <span className="bg-gradient-to-r from-[#f0f4ff] to-[#c4b5fd] bg-clip-text text-transparent">
                    Your Review
                  </span>
                </h3>

                <div className="p-5 rounded-xl bg-[#1a1a2e]/80 border border-[#8b5cf6]/20 mb-4">
                  <p
                    className="text-[#b8c1ec] leading-relaxed"
                    style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                  >
                    An absolute masterpiece that redefined the shounen genre. The plot twists are incredible, the character development is phenomenal, and the final season ties everything together perfectly. Eren's journey from a hopeful protagonist to a complex anti-hero is brilliantly executed. The animation quality, especially in the final seasons, is breathtaking.
                  </p>
                </div>

                <div className="flex items-center gap-3 text-xs text-[#8b5cf6]">
                  <Clock className="w-4 h-4" />
                  <span style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                    Reviewed on March 8, 2024
                  </span>
                </div>
              </motion.div>

              {/* Similar Content */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <h3
                  className="text-2xl mb-6 flex items-center gap-2"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  <Award className="w-6 h-6 text-[#8b5cf6]" />
                  <span className="bg-gradient-to-r from-[#f0f4ff] to-[#c4b5fd] bg-clip-text text-transparent">
                    Similar Anime
                  </span>
                </h3>

                <div className="grid sm:grid-cols-2 gap-4">
                  {[
                    { title: 'Death Note', rating: '9.0', image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwYW5pbWUlMjBjaGFyYWN0ZXJ8ZW58MXx8fHwxNzc2MjA5MDY0fDA&ixlib=rb-4.1.0&q=80&w=1080' },
                    { title: 'Code Geass', rating: '8.7', image: 'https://images.unsplash.com/photo-1578632292335-df3abbb0d586?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmltZSUyMG1lY2hhfGVufDF8fHx8MTc3NjIwOTA2NHww&ixlib=rb-4.1.0&q=80&w=1080' },
                  ].map((item) => (
                    <div
                      key={item.title}
                      className="flex gap-4 p-4 rounded-xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all cursor-pointer group"
                    >
                      <div className="relative w-20 h-28 rounded-lg overflow-hidden flex-shrink-0">
                        <ImageWithFallback
                          src={item.image}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4
                          className="text-lg mb-2 text-[#f0f4ff] truncate"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                        >
                          {item.title}
                        </h4>
                        <div className="flex items-center gap-1 mb-2">
                          <Star className="w-4 h-4 fill-[#fbbf24] text-[#fbbf24]" />
                          <span className="text-sm text-[#f0f4ff] font-bold" style={{ fontFamily: 'var(--font-body)' }}>
                            {item.rating}
                          </span>
                        </div>
                        <span className="text-xs text-[#8b5cf6]" style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                          View Details →
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Right Sidebar - Metadata */}
            <div className="space-y-6">
              {/* Tracking Details */}
              <motion.div
                className="p-6 rounded-2xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <h3
                  className="text-xl mb-5 text-[#f0f4ff]"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Details
                </h3>

                <div className="space-y-4">
                  {[
                    { label: 'Episodes', value: '87 episodes', icon: Tv },
                    { label: 'Seasons', value: '4 seasons', icon: Film },
                    { label: 'Studio', value: 'MAPPA, Wit Studio', icon: Award },
                    { label: 'Aired', value: 'Apr 7, 2013 - Nov 5, 2023', icon: Calendar },
                    { label: 'Duration', value: '24 min per ep', icon: Clock },
                  ].map((detail) => (
                    <div key={detail.label} className="flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-[#8b5cf6]/20 flex-shrink-0">
                        <detail.icon className="w-4 h-4 text-[#8b5cf6]" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div
                          className="text-xs text-[#b8c1ec] mb-1"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                        >
                          {detail.label}
                        </div>
                        <div
                          className="text-sm text-[#f0f4ff]"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                        >
                          {detail.value}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Community Stats */}
              <motion.div
                className="p-6 rounded-2xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                <h3
                  className="text-xl mb-5 text-[#f0f4ff]"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Community Stats
                </h3>

                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-[#1a1a2e]/80 border border-[#8b5cf6]/20">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-[#b8c1ec]" style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                        Watching
                      </span>
                      <span className="text-lg font-bold text-[#8b5cf6]" style={{ fontFamily: 'var(--font-display)' }}>
                        1.2M
                      </span>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-[#1a1a2e]/80 border border-[#8b5cf6]/20">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-[#b8c1ec]" style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                        Completed
                      </span>
                      <span className="text-lg font-bold text-green-500" style={{ fontFamily: 'var(--font-display)' }}>
                        3.8M
                      </span>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-[#1a1a2e]/80 border border-[#8b5cf6]/20">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-[#b8c1ec]" style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                        Plan to Watch
                      </span>
                      <span className="text-lg font-bold text-blue-500" style={{ fontFamily: 'var(--font-display)' }}>
                        2.1M
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Quick Actions Card */}
              <motion.div
                className="p-6 rounded-2xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <h3
                  className="text-xl mb-4 text-[#f0f4ff]"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Quick Actions
                </h3>

                <div className="space-y-3">
                  <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[#8b5cf6]/20 hover:bg-[#8b5cf6]/30 border border-[#8b5cf6]/40 transition-all text-[#c4b5fd]">
                    <Check className="w-4 h-4" />
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      Mark as Completed
                    </span>
                  </button>

                  <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 border border-[#8b5cf6]/20 transition-all text-[#b8c1ec]">
                    <Heart className="w-4 h-4" />
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      Add to Favorites
                    </span>
                  </button>

                  <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 border border-[#8b5cf6]/20 transition-all text-[#b8c1ec]">
                    <Edit className="w-4 h-4" />
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      Edit Review
                    </span>
                  </button>
                </div>
              </motion.div>
            </div>
          </div>
        </main>
      </div>

      {/* Edit Entry Modal */}
      <EditEntryModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        item={itemData}
      />
    </div>
  );
}