import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Sparkles, Film, Gamepad2, Tv } from 'lucide-react';
import Navigation from '../components/Navigation';
import HeroZeus from '../components/HeroZeus';
import LoginOverlay from '../components/LoginOverlay';
import SignUpOverlay from '../components/SignUpOverlay';

export default function LandingPage() {
  const navigate = useNavigate();
  const [isLoaded, setIsLoaded] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const handleSwitchToSignUp = () => {
    setShowLogin(false);
    setShowSignUp(true);
  };

  const handleSwitchToLogin = () => {
    setShowSignUp(false);
    setShowLogin(true);
  };

  const handleLoginSuccess = () => {
    setShowLogin(false);
    navigate('/dashboard');
  };

  const handleSignUpSuccess = () => {
    setShowSignUp(false);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white overflow-x-hidden antialiased">
      {/* Cosmic Background */}
      <div className="fixed inset-0 z-0">
        {/* Base gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f1729] via-[#0a0a0f] to-[#0a0a0f]" />

        {/* Cosmic gradients - more refined */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(139,92,246,0.12),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_30%,rgba(99,102,241,0.08),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_80%,rgba(59,130,246,0.06),transparent_50%)]" />

        {/* Subtle vignette effect */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(10,10,15,0.4)_100%)]" />

        {/* Noise texture overlay for premium feel */}
        <div className="absolute inset-0 opacity-[0.015] mix-blend-overlay">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' /%3E%3C/svg%3E")`,
            }}
          />
        </div>

        {/* Refined animated stars - fewer and more subtle */}
        <div className="absolute inset-0 opacity-30">
          {[...Array(30)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-[2px] h-[2px] bg-white rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                opacity: [0.1, 0.6, 0.1],
                scale: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 4 + Math.random() * 3,
                repeat: Infinity,
                delay: Math.random() * 3,
                ease: 'easeInOut',
              }}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10">
        <Navigation
          onLoginClick={() => setShowLogin(true)}
          onSignUpClick={() => setShowSignUp(true)}
        />

        {/* Hero Section */}
        <section className="relative px-6 min-h-[95vh] flex items-center overflow-hidden">
          {/* Zeus Background */}
          <HeroZeus />

          {/* Subtle text readability gradient - positioned behind text area */}
          <div className="absolute inset-0 pointer-events-none z-[5]">
            <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0f]/70 via-[#0a0a0f]/30 to-transparent" />
            <div className="absolute top-1/2 -translate-y-1/2 left-0 w-[50%] h-[75%] bg-gradient-to-br from-[#0a0a0f]/60 via-[#0a0a0f]/35 to-transparent blur-[80px]" />
            <div className="absolute top-1/2 -translate-y-1/2 left-[5%] w-[45%] h-[60%] bg-[#0a0a0f]/40 blur-[60px]" />
          </div>

          {/* Hero content overlay */}
          <div className="max-w-[1450px] mx-auto relative z-10 w-full">
            <div className="max-w-3xl lg:max-w-2xl xl:max-w-3xl lg:ml-[8%] xl:ml-[10%]">
              {/* Eyebrow */}
              <motion.div
                className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full border border-[#8b5cf6]/60 bg-gradient-to-r from-[#8b5cf6]/30 to-[#6366f1]/25 backdrop-blur-md mb-8 shadow-[0_0_30px_rgba(139,92,246,0.3)]"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : -10 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <Sparkles className="w-4 h-4 text-[#a78bfa]" />
                <span className="text-sm tracking-wider text-[#e9d5ff]" style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}>
                  Your universe of taste
                </span>
              </motion.div>

              {/* Headline */}
              <motion.h1
                className="mb-7"
                style={{ fontFamily: 'var(--font-display)' }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                <span className="block text-[3.75rem] lg:text-[4.75rem] xl:text-[5.5rem] leading-[1.05] tracking-tight">
                  <span className="bg-gradient-to-br from-[#f0f4ff] via-[#d4c5f9] to-[#c4b5fd] bg-clip-text text-transparent drop-shadow-[0_6px_30px_rgba(10,10,15,1)] [text-shadow:_0_3px_24px_rgba(139,92,246,0.6)]">
                    Organize your
                  </span>
                </span>
                <span className="block text-[3.75rem] lg:text-[4.75rem] xl:text-[5.5rem] leading-[1.05] tracking-tight mt-2 lg:mt-3">
                  <span className="bg-gradient-to-br from-[#c4b5fd] via-[#a78bfa] to-[#8b5cf6] bg-clip-text text-transparent drop-shadow-[0_6px_30px_rgba(10,10,15,1)] [text-shadow:_0_3px_24px_rgba(139,92,246,0.7)]">
                    anime, movies,
                  </span>
                </span>
                <span className="block text-[3.75rem] lg:text-[4.75rem] xl:text-[5.5rem] leading-[1.05] tracking-tight mt-2 lg:mt-3 text-[#f0f4ff] drop-shadow-[0_6px_32px_rgba(10,10,15,1)] [text-shadow:_0_3px_28px_rgba(139,92,246,0.5)]">
                  and games.
                </span>
              </motion.h1>

              {/* Subheadline */}
              <motion.p
                className="text-[1.2rem] lg:text-[1.4rem] text-[#d4c5f9] mb-11 max-w-2xl leading-[1.7] drop-shadow-[0_4px_20px_rgba(10,10,15,1)]"
                style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              >
                Build your personal universe with ratings, favorites, reviews, and lists — all inside olYmpos.
              </motion.p>

              {/* CTA Buttons */}
              <motion.div
                className="flex flex-wrap gap-5"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
                transition={{ duration: 0.8, delay: 0.6 }}
              >
                <button
                  onClick={() => setShowLogin(true)}
                  className="group relative px-10 py-4 bg-gradient-to-br from-[#8b5cf6] via-[#7c3aed] to-[#6366f1] rounded-xl overflow-hidden transition-all hover:scale-[1.03] shadow-[0_0_50px_rgba(139,92,246,0.5)] hover:shadow-[0_0_70px_rgba(139,92,246,0.8)]"
                  style={{ fontFamily: 'var(--font-body)' }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-[#a78bfa] via-[#9333ea] to-[#818cf8] opacity-0 group-hover:opacity-100 transition-all duration-300" />
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.35),transparent_50%)]" />
                  </div>
                  <span className="relative z-10 font-semibold text-lg text-white">Get Started</span>
                </button>

                <button
                  className="group px-10 py-4 border-2 border-[#8b5cf6]/60 rounded-xl backdrop-blur-md hover:bg-[#8b5cf6]/25 transition-all hover:border-[#8b5cf6] relative overflow-hidden shadow-[0_0_25px_rgba(139,92,246,0.2)]"
                  style={{ fontFamily: 'var(--font-body)' }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-[#8b5cf6]/0 via-[#8b5cf6]/20 to-[#8b5cf6]/0 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span className="relative font-semibold text-lg text-[#f0f4ff]">See Features</span>
                </button>
              </motion.div>
            </div>
          </div>

          {/* Bottom fade to next section - layered atmospheric transition */}
          <div className="absolute inset-x-0 bottom-0 pointer-events-none">
            {/* Primary gradient fade */}
            <div className="h-56 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f]/80 to-transparent" />

            {/* Secondary soft fade layer */}
            <div className="absolute inset-x-0 bottom-0 h-72 bg-gradient-to-t from-[#0a0a0f]/90 via-[#0a0a0f]/40 to-transparent" />

            {/* Atmospheric cosmic fade */}
            <motion.div
              className="absolute inset-x-0 bottom-0 h-64"
              style={{
                background: 'linear-gradient(to top, #0a0a0f 0%, rgba(10,10,15,0.7) 30%, rgba(10,10,15,0.3) 60%, transparent 100%)',
              }}
              animate={{
                opacity: [0.8, 1, 0.8],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />

            {/* Subtle cosmic glow in transition */}
            <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-[#0a0a0f] via-[rgba(139,92,246,0.02)] to-transparent" />
          </div>
        </section>

        {/* Category Cards Section */}
        <section className="relative px-6 py-28 lg:py-36">
          <div className="max-w-[1400px] mx-auto">
            <motion.div
              className="text-center mb-16 lg:mb-20"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2
                className="text-5xl lg:text-6xl mb-5 bg-gradient-to-br from-[#f0f4ff] via-[#c4b5fd] to-[#a78bfa] bg-clip-text text-transparent tracking-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Track Everything You Love
              </h2>
              <p
                className="text-xl lg:text-[1.35rem] text-[#b8c1ec] max-w-2xl mx-auto leading-relaxed"
                style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
              >
                One platform for all your entertainment. Rate, review, and organize your universe.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-7 lg:gap-8">
              {[
                {
                  icon: Tv,
                  title: 'Anime',
                  description: 'Track series, rate episodes, and build your watchlist.',
                  gradient: 'from-[#c026d3] via-[#a855f7] to-[#9333ea]',
                  borderGradient: 'from-[#c026d3]/35 to-[#9333ea]/35',
                  glowColor: 'rgba(192, 38, 211, 0.3)',
                  iconBg: 'from-[#c026d3] to-[#a855f7]',
                  accentColor: '#c026d3',
                  delay: 0.2,
                },
                {
                  icon: Film,
                  title: 'Movies',
                  description: 'Organize your collection, write reviews, and curate your cinema.',
                  gradient: 'from-[#8b5cf6] via-[#7c3aed] to-[#6366f1]',
                  borderGradient: 'from-[#8b5cf6]/35 to-[#6366f1]/35',
                  glowColor: 'rgba(139, 92, 246, 0.3)',
                  iconBg: 'from-[#8b5cf6] to-[#7c3aed]',
                  accentColor: '#8b5cf6',
                  delay: 0.3,
                },
                {
                  icon: Gamepad2,
                  title: 'Games',
                  description: 'Track your gaming journey with ratings and progress logs.',
                  gradient: 'from-[#3b82f6] via-[#2563eb] to-[#1d4ed8]',
                  borderGradient: 'from-[#3b82f6]/35 to-[#1d4ed8]/35',
                  glowColor: 'rgba(59, 130, 246, 0.3)',
                  iconBg: 'from-[#3b82f6] to-[#2563eb]',
                  accentColor: '#3b82f6',
                  delay: 0.4,
                },
              ].map((category) => (
                <motion.div
                  key={category.title}
                  className="group relative"
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.7, delay: category.delay, ease: [0.25, 0.1, 0.25, 1] }}
                >
                  {/* Card Glow Effect - subtle category-specific */}
                  <motion.div
                    className={`absolute -inset-1 bg-gradient-to-br ${category.gradient} blur-2xl rounded-3xl transition-all duration-700`}
                    style={{ opacity: 0.15 }}
                    whileHover={{ opacity: 0.35, scale: 1.03 }}
                    transition={{ duration: 0.5 }}
                  />

                  {/* Subtle ambient category glow - always visible */}
                  <div
                    className="absolute -inset-0.5 rounded-3xl opacity-20"
                    style={{
                      background: `radial-gradient(circle at 50% 50%, ${category.glowColor}, transparent 70%)`,
                      filter: 'blur(20px)',
                    }}
                  />

                  <div
                    className="relative p-9 lg:p-10 rounded-3xl border bg-gradient-to-br from-[#0f1729]/85 via-[#0a0a0f]/70 to-[#0f1729]/85 backdrop-blur-md hover:from-[#0f1729]/95 hover:via-[#0a0a0f]/80 hover:to-[#0f1729]/95 transition-all duration-500 h-full overflow-hidden shadow-[0_8px_40px_rgba(0,0,0,0.3)]"
                    style={{
                      borderImage: `linear-gradient(135deg, ${category.borderGradient.replace('from-', '').replace(' to-', ', ')}) 1`,
                      borderWidth: '1.5px',
                      borderStyle: 'solid',
                    }}
                  >
                    {/* Ambient light effect - refined */}
                    <div
                      className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${category.gradient} opacity-70 group-hover:opacity-90 transition-opacity duration-500`}
                      style={{
                        boxShadow: `0 0 12px ${category.accentColor}40`,
                      }}
                    />

                    {/* Icon */}
                    <motion.div
                      className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${category.iconBg} mb-7 shadow-[0_8px_32px_rgba(0,0,0,0.5)] relative overflow-hidden`}
                      whileHover={{ scale: 1.05, rotate: 3 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      <category.icon className="w-8 h-8 text-white relative z-10" />
                    </motion.div>

                    {/* Title */}
                    <h3
                      className="text-[1.75rem] lg:text-3xl mb-3.5 bg-gradient-to-br from-[#f0f4ff] to-[#d4c5f9] bg-clip-text text-transparent tracking-tight"
                      style={{ fontFamily: 'var(--font-display)' }}
                    >
                      {category.title}
                    </h3>

                    {/* Description */}
                    <p
                      className="text-[#b8c1ec] leading-relaxed text-base lg:text-[1.05rem]"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                    >
                      {category.description}
                    </p>

                    {/* Decorative corner element - more subtle */}
                    <div className="absolute bottom-0 right-0 w-28 h-28 opacity-8 group-hover:opacity-16 transition-opacity duration-500">
                      <div className={`w-full h-full bg-gradient-to-tl ${category.gradient} rounded-tl-full`} />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Login Overlay */}
        {showLogin && (
          <LoginOverlay
            onClose={() => setShowLogin(false)}
            onSwitchToSignUp={handleSwitchToSignUp}
            onSuccess={handleLoginSuccess}
          />
        )}

        {/* Sign Up Overlay */}
        {showSignUp && (
          <SignUpOverlay
            onClose={() => setShowSignUp(false)}
            onSwitchToLogin={handleSwitchToLogin}
            onSuccess={handleSignUpSuccess}
          />
        )}
      </div>
    </div>
  );
}
