import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Bell, Settings, Tv, Film, Gamepad2, Plus, Star, LogOut, Zap, Filter, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { Sparkles } from 'lucide-react';

// Mock data for library items
const mockLibraryItems = [
  {
    id: 1,
    title: 'Attack on Titan',
    category: 'anime',
    image: 'https://images.unsplash.com/photo-1764520408437-95890a95db4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmltZSUyMGNoYXJhY3RlciUyMHBvc3RlcnxlbnwxfHx8fDE3NzYyMDkwNjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'watching',
    rating: 5,
    isFavorite: true,
    progress: 'S4 E12',
  },
  {
    id: 2,
    title: 'Inception',
    category: 'movie',
    image: 'https://images.unsplash.com/photo-1563202221-f4eae97e4828?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWF0aWMlMjBtb3ZpZSUyMHNjZW5lfGVufDF8fHx8MTc3NjIwOTA2M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'completed',
    rating: 5,
    isFavorite: true,
  },
  {
    id: 3,
    title: 'Elden Ring',
    category: 'game',
    image: 'https://images.unsplash.com/photo-1634658340808-9abaef7eb9a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2ktZmklMjB2aWRlbyUyMGdhbWUlMjBhcnR8ZW58MXx8fHwxNzc2MjA5MDY0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'playing',
    rating: 5,
    isFavorite: false,
    progress: '78%',
  },
  {
    id: 4,
    title: 'Your Name',
    category: 'anime',
    image: 'https://images.unsplash.com/photo-1763732397784-c5ff2651d40c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMG1hbmdhJTIwYXJ0d29ya3xlbnwxfHx8fDE3NzYyMDkwNjR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'completed',
    rating: 5,
    isFavorite: true,
  },
  {
    id: 5,
    title: 'Interstellar',
    category: 'movie',
    image: 'https://images.unsplash.com/photo-1765510296004-614b6cc204da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBtb3ZpZSUyMHBvc3RlcnxlbnwxfHx8fDE3NzYxNDc4NDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'completed',
    rating: 5,
    isFavorite: true,
  },
  {
    id: 6,
    title: 'The Last of Us Part II',
    category: 'game',
    image: 'https://images.unsplash.com/photo-1592840496694-26d035b52b48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWRlbyUyMGdhbWUlMjBjb250cm9sbGVyfGVufDF8fHx8MTc3NjIwMTk4OXww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'completed',
    rating: 5,
    isFavorite: true,
  },
  {
    id: 7,
    title: 'Demon Slayer',
    category: 'anime',
    image: 'https://images.unsplash.com/photo-1612036781124-847f8939b154?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmltZSUyMHdhcnJpb3J8ZW58MXx8fHwxNzc2MjA5MDY1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'watching',
    rating: 4,
    isFavorite: false,
    progress: 'S2 E8',
  },
  {
    id: 8,
    title: 'The Matrix',
    category: 'movie',
    image: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2ktZmklMjBjaW5lbWF8ZW58MXx8fHwxNzc2MjA5MDY1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'completed',
    rating: 5,
    isFavorite: false,
  },
  {
    id: 9,
    title: 'God of War',
    category: 'game',
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXRob2xvZ3klMjBnYW1lfGVufDF8fHx8MTc3NjIwOTA2NXww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'playing',
    rating: 5,
    isFavorite: true,
    progress: '45%',
  },
  {
    id: 10,
    title: 'Cowboy Bebop',
    category: 'anime',
    image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMGFuaW1lfGVufDF8fHx8MTc3NjIwOTA2Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'planned',
    rating: 0,
    isFavorite: false,
  },
  {
    id: 11,
    title: 'Dune',
    category: 'movie',
    image: 'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNlcnQlMjBzY2ktZml8ZW58MXx8fHwxNzc2MjA5MDY2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'planned',
    rating: 0,
    isFavorite: false,
  },
  {
    id: 12,
    title: 'Hades',
    category: 'game',
    image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXRob2xvZ3klMjBhcnR8ZW58MXx8fHwxNzc2MjA5MDY2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'completed',
    rating: 5,
    isFavorite: true,
  },
];

type CategoryFilter = 'all' | 'anime' | 'movie' | 'game';
type StatusFilter = 'all' | 'favorites' | 'completed' | 'watching' | 'planned';
type SortOption = 'recent' | 'rating' | 'alphabetical';

export default function Library() {
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [sortOption, setSortOption] = useState<SortOption>('recent');
  const [showSortMenu, setShowSortMenu] = useState(false);

  // Filter and sort logic
  const filteredItems = mockLibraryItems
    .filter((item) => {
      if (categoryFilter !== 'all' && item.category !== categoryFilter) return false;
      if (statusFilter === 'favorites' && !item.isFavorite) return false;
      if (statusFilter === 'completed' && item.status !== 'completed') return false;
      if (statusFilter === 'watching' && item.status !== 'watching' && item.status !== 'playing') return false;
      if (statusFilter === 'planned' && item.status !== 'planned') return false;
      return true;
    })
    .sort((a, b) => {
      if (sortOption === 'rating') return b.rating - a.rating;
      if (sortOption === 'alphabetical') return a.title.localeCompare(b.title);
      return 0; // recent (default order)
    });

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      watching: 'Watching',
      playing: 'Playing',
      completed: 'Completed',
      planned: 'Planned',
    };
    return labels[status] || status;
  };

  const getCategoryIcon = (category: string) => {
    if (category === 'anime') return Tv;
    if (category === 'movie') return Film;
    if (category === 'game') return Gamepad2;
    return Tv;
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white antialiased">
      {/* Cosmic Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f1729] via-[#0a0a0f] to-[#0a0a0f]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(139,92,246,0.06),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_30%,rgba(99,102,241,0.04),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(10,10,15,0.3)_100%)]" />
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Top Navigation - same as Dashboard */}
        <nav className="border-b border-[#8b5cf6]/10 bg-[#0a0a0f]/80 backdrop-blur-xl sticky top-0 z-50">
          <div className="max-w-[1600px] mx-auto px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              {/* Logo with Icon */}
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Zap className="w-7 h-7 text-[#8b5cf6] fill-[#8b5cf6] relative z-10" />
                  <motion.div
                    className="absolute inset-0 blur-lg bg-[#8b5cf6] opacity-40"
                    animate={{
                      opacity: [0.4, 0.6, 0.4],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                  />
                </div>
                <h1
                  className="text-2xl tracking-tight bg-gradient-to-br from-[#f0f4ff] via-[#c4b5fd] to-[#a78bfa] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  olYmpos
                </h1>
              </div>

              {/* Right Side with Search and Profile */}
              <div className="flex items-center gap-6">
                {/* Search Bar */}
                <div className="hidden md:block">
                  <div className="relative w-[320px]">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8b5cf6]/50" />
                    <input
                      type="text"
                      placeholder="Search anime, movies, games..."
                      className="w-full pl-12 pr-5 py-2.5 bg-[#1a1a2e]/60 border border-[#8b5cf6]/20 rounded-xl text-white placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/40 focus:border-[#8b5cf6] transition-all text-sm"
                      style={{ fontFamily: 'var(--font-body)' }}
                    />
                  </div>
                </div>

                {/* Notification */}
                <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors relative">
                  <Bell className="w-5 h-5 text-[#b8c1ec]" />
                  <span className="absolute top-2 right-2 w-2 h-2 bg-[#8b5cf6] rounded-full" />
                </button>

                {/* Settings */}
                <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors">
                  <Settings className="w-5 h-5 text-[#b8c1ec]" />
                </button>

                {/* Profile Avatar */}
                <div className="flex items-center gap-3 pl-3 pr-4 py-2 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#6366f1]/20 border border-[#8b5cf6]/30 cursor-pointer hover:from-[#8b5cf6]/30 hover:to-[#6366f1]/30 transition-all">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#6366f1] flex items-center justify-center">
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      JD
                    </span>
                  </div>
                  <span className="text-sm text-[#e9d5ff] font-medium hidden lg:block" style={{ fontFamily: 'var(--font-body)' }}>
                    John Doe
                  </span>
                </div>

                {/* Sign Out Button */}
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 hover:bg-[#8b5cf6]/10 transition-all text-[#b8c1ec] hover:text-[#e9d5ff]">
                  <LogOut className="w-4 h-4" />
                  <span className="text-sm font-medium hidden xl:block" style={{ fontFamily: 'var(--font-body)' }}>
                    Sign Out
                  </span>
                </button>
              </div>
            </div>
          </div>
        </nav>

        {/* Library Content */}
        <main className="max-w-[1600px] mx-auto px-6 lg:px-8 py-12">
          {/* Page Header */}
          <motion.div
            className="mb-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative mb-3">
              {/* Decorative sparkle accent behind heading */}
              <Sparkles className="absolute -left-3 top-1/2 -translate-y-1/2 w-16 h-16 text-[#8b5cf6] opacity-[0.08] -z-10" />
              <h2
                className="text-4xl lg:text-5xl tracking-tight bg-gradient-to-br from-[#f0f4ff] via-[#d4c5f9] to-[#c4b5fd] bg-clip-text text-transparent"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Your Library
              </h2>
            </div>
            <p
              className="text-lg text-[#b8c1ec]"
              style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
            >
              Browse and manage your anime, movies, and games.
            </p>
          </motion.div>

          {/* Controls Section */}
          <motion.div
            className="mb-8 space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            {/* Top Row: Category Tabs + Add Actions */}
            <div className="flex items-center justify-between gap-6 flex-wrap">
              {/* Category Tabs */}
              <div className="flex items-center gap-2 p-1.5 rounded-xl bg-[#1a1a2e]/60 border border-[#8b5cf6]/20">
                {[
                  { value: 'all', label: 'All', icon: Filter },
                  { value: 'anime', label: 'Anime', icon: Tv },
                  { value: 'movie', label: 'Movies', icon: Film },
                  { value: 'game', label: 'Games', icon: Gamepad2 },
                ].map((tab) => (
                  <button
                    key={tab.value}
                    onClick={() => setCategoryFilter(tab.value as CategoryFilter)}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-lg transition-all duration-300 ${
                      categoryFilter === tab.value
                        ? 'bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] text-white shadow-lg'
                        : 'text-[#b8c1ec] hover:text-white hover:bg-white/5'
                    }`}
                    style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                  >
                    <tab.icon className="w-4 h-4" />
                    <span className="hidden sm:inline">{tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Add Actions */}
              <div className="flex items-center gap-3">
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] hover:from-[#a78bfa] hover:to-[#818cf8] transition-all shadow-lg hover:shadow-xl text-white">
                  <Plus className="w-4 h-4" />
                  <span className="text-sm font-semibold hidden sm:inline" style={{ fontFamily: 'var(--font-body)' }}>
                    Add Content
                  </span>
                </button>
              </div>
            </div>

            {/* Bottom Row: Status Filters + Sorting */}
            <div className="flex items-center justify-between gap-6 flex-wrap">
              {/* Status Filters */}
              <div className="flex items-center gap-2 flex-wrap">
                {[
                  { value: 'all', label: 'All Status' },
                  { value: 'favorites', label: 'Favorites' },
                  { value: 'completed', label: 'Completed' },
                  { value: 'watching', label: 'Watching/Playing' },
                  { value: 'planned', label: 'Planned' },
                ].map((filter) => (
                  <button
                    key={filter.value}
                    onClick={() => setStatusFilter(filter.value as StatusFilter)}
                    className={`px-4 py-2 rounded-lg transition-all duration-300 text-sm ${
                      statusFilter === filter.value
                        ? 'bg-[#8b5cf6]/20 text-[#a78bfa] border border-[#8b5cf6]/40'
                        : 'text-[#b8c1ec] hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                    style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>

              {/* Sort Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowSortMenu(!showSortMenu)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#1a1a2e]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all text-[#b8c1ec] hover:text-white"
                  style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                >
                  <SlidersHorizontal className="w-4 h-4" />
                  <span className="text-sm">
                    {sortOption === 'recent' && 'Recently Added'}
                    {sortOption === 'rating' && 'Highest Rated'}
                    {sortOption === 'alphabetical' && 'A-Z'}
                  </span>
                  <ChevronDown className="w-4 h-4" />
                </button>

                {showSortMenu && (
                  <motion.div
                    className="absolute right-0 top-full mt-2 w-48 p-2 rounded-xl bg-[#1a1a2e] border border-[#8b5cf6]/30 shadow-xl z-10"
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    {[
                      { value: 'recent', label: 'Recently Added' },
                      { value: 'rating', label: 'Highest Rated' },
                      { value: 'alphabetical', label: 'A-Z' },
                    ].map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          setSortOption(option.value as SortOption);
                          setShowSortMenu(false);
                        }}
                        className={`w-full text-left px-4 py-2.5 rounded-lg transition-all text-sm ${
                          sortOption === option.value
                            ? 'bg-[#8b5cf6]/20 text-[#a78bfa]'
                            : 'text-[#b8c1ec] hover:bg-white/5 hover:text-white'
                        }`}
                        style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                      >
                        {option.label}
                      </button>
                    ))}
                  </motion.div>
                )}
              </div>
            </div>
          </motion.div>

          {/* Results Count */}
          <motion.div
            className="mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <p
              className="text-sm text-[#8b5cf6]"
              style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
            >
              {filteredItems.length} {filteredItems.length === 1 ? 'item' : 'items'}
            </p>
          </motion.div>

          {/* Library Grid */}
          <motion.div
            className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            {filteredItems.map((item) => {
              const CategoryIcon = getCategoryIcon(item.category);
              return (
                <motion.div
                  key={item.id}
                  className="group relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all duration-300 cursor-pointer"
                  whileHover={{ y: -6, scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Image */}
                  <div className="relative h-80 overflow-hidden">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    {/* Gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f]/60 to-transparent" />

                    {/* Category Badge */}
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0a0a0f]/80 backdrop-blur-md border border-[#8b5cf6]/30">
                      <CategoryIcon className="w-3.5 h-3.5 text-[#8b5cf6]" />
                      <span
                        className="text-xs text-[#b8c1ec] capitalize font-medium"
                        style={{ fontFamily: 'var(--font-body)' }}
                      >
                        {item.category}
                      </span>
                    </div>

                    {/* Favorite Indicator */}
                    {item.isFavorite && (
                      <div className="absolute top-3 right-3 p-2 rounded-lg bg-[#8b5cf6]/80 backdrop-blur-md">
                        <Star className="w-4 h-4 fill-white text-white" />
                      </div>
                    )}

                    {/* Rating */}
                    {item.rating > 0 && (
                      <div className="absolute bottom-3 right-3 flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#0a0a0f]/80 backdrop-blur-md">
                        <Star className="w-4 h-4 fill-[#fbbf24] text-[#fbbf24]" />
                        <span className="text-sm font-semibold text-white" style={{ fontFamily: 'var(--font-body)' }}>
                          {item.rating}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-5">
                    <h4
                      className="text-lg mb-2 text-[#f0f4ff] line-clamp-1"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                    >
                      {item.title}
                    </h4>

                    {/* Status */}
                    <div className="flex items-center justify-between">
                      <span
                        className="inline-block px-3 py-1 rounded-lg text-xs font-medium bg-[#8b5cf6]/20 text-[#a78bfa] border border-[#8b5cf6]/30"
                        style={{ fontFamily: 'var(--font-body)' }}
                      >
                        {getStatusLabel(item.status)}
                      </span>

                      {item.progress && (
                        <span
                          className="text-sm text-[#b8c1ec]"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                        >
                          {item.progress}
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Empty State */}
          {filteredItems.length === 0 && (
            <motion.div
              className="flex flex-col items-center justify-center py-20"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
            >
              <div className="p-6 rounded-full bg-[#8b5cf6]/10 mb-6">
                <Filter className="w-12 h-12 text-[#8b5cf6]" />
              </div>
              <h3
                className="text-2xl mb-3 text-[#f0f4ff]"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                No items found
              </h3>
              <p
                className="text-[#b8c1ec] mb-6"
                style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
              >
                Try adjusting your filters or add new content to your library.
              </p>
              <button className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] hover:from-[#a78bfa] hover:to-[#818cf8] transition-all shadow-lg text-white">
                <Plus className="w-5 h-5" />
                <span className="font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                  Add Content
                </span>
              </button>
            </motion.div>
          )}
        </main>
      </div>
    </div>
  );
}