import { motion } from 'motion/react';
import { Search, Bell, Settings, Tv, Film, Gamepad2, Plus, Star, Clock, TrendingUp, Sparkles, LogOut, Zap } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

// Mock data for the dashboard
const mockStats = {
  anime: 47,
  movies: 132,
  games: 28,
};

const mockRecentlyTracked = [
  {
    id: 1,
    title: 'Attack on Titan',
    type: 'anime',
    image: 'https://images.unsplash.com/photo-1764520408437-95890a95db4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmltZSUyMGNoYXJhY3RlciUyMHBvc3RlcnxlbnwxfHx8fDE3NzYyMDkwNjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    progress: 'S4 E12',
    rating: 5,
  },
  {
    id: 2,
    title: 'Inception',
    type: 'movie',
    image: 'https://images.unsplash.com/photo-1563202221-f4eae97e4828?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWF0aWMlMjBtb3ZpZSUyMHNjZW5lfGVufDF8fHx8MTc3NjIwOTA2M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    progress: 'Watched',
    rating: 5,
  },
  {
    id: 3,
    title: 'Elden Ring',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1634658340808-9abaef7eb9a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2ktZmklMjB2aWRlbyUyMGdhbWUlMjBhcnR8ZW58MXx8fHwxNzc2MjA5MDY0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    progress: '78% Complete',
    rating: 5,
  },
];

const mockFavorites = [
  {
    id: 4,
    title: 'Your Name',
    type: 'anime',
    image: 'https://images.unsplash.com/photo-1763732397784-c5ff2651d40c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMG1hbmdhJTIwYXJ0d29ya3xlbnwxfHx8fDE3NzYyMDkwNjR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 5,
  },
  {
    id: 5,
    title: 'Interstellar',
    type: 'movie',
    image: 'https://images.unsplash.com/photo-1765510296004-614b6cc204da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBtb3ZpZSUyMHBvc3RlcnxlbnwxfHx8fDE3NzYxNDc4NDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 5,
  },
  {
    id: 6,
    title: 'The Last of Us Part II',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1592840496694-26d035b52b48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWRlbyUyMGdhbWUlMjBjb250cm9sbGVyfGVufDF8fHx8MTc3NjIwMTk4OXww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 5,
  },
];

const mockReviews = [
  {
    id: 1,
    title: 'Attack on Titan',
    type: 'anime',
    rating: 5,
    review: 'An absolute masterpiece. The story keeps getting better with each season.',
    date: '2 days ago',
  },
  {
    id: 2,
    title: 'Inception',
    type: 'movie',
    rating: 5,
    review: 'Mind-bending and visually stunning. Christopher Nolan at his best.',
    date: '5 days ago',
  },
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white antialiased">
      {/* Cosmic Background - subtle version for dashboard */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f1729] via-[#0a0a0f] to-[#0a0a0f]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(139,92,246,0.06),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_30%,rgba(99,102,241,0.04),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(10,10,15,0.3)_100%)]" />
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Top Navigation */}
        <nav className="border-b border-[#8b5cf6]/10 bg-[#0a0a0f]/80 backdrop-blur-xl sticky top-0 z-50">
          <div className="max-w-[1600px] mx-auto px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              {/* Logo with Icon */}
              <div className="flex items-center gap-3">
                {/* olYmpos Symbol/Icon - matching Navigation */}
                <div className="relative">
                  <Zap className="w-7 h-7 text-[#8b5cf6] fill-[#8b5cf6] relative z-10" />
                  <motion.div
                    className="absolute inset-0 blur-lg bg-[#8b5cf6] opacity-40"
                    animate={{
                      opacity: [0.4, 0.6, 0.4],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                  />
                </div>
                <h1
                  className="text-2xl tracking-tight bg-gradient-to-br from-[#f0f4ff] via-[#c4b5fd] to-[#a78bfa] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  olYmpos
                </h1>
              </div>

              {/* Right Side with Search and Profile */}
              <div className="flex items-center gap-6">
                {/* Search Bar - moved to the right */}
                <div className="hidden md:block">
                  <div className="relative w-[320px]">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8b5cf6]/50" />
                    <input
                      type="text"
                      placeholder="Search anime, movies, games..."
                      className="w-full pl-12 pr-5 py-2.5 bg-[#1a1a2e]/60 border border-[#8b5cf6]/20 rounded-xl text-white placeholder:text-[#6b7280] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/40 focus:border-[#8b5cf6] transition-all text-sm"
                      style={{ fontFamily: 'var(--font-body)' }}
                    />
                  </div>
                </div>

                {/* Notification */}
                <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors relative">
                  <Bell className="w-5 h-5 text-[#b8c1ec]" />
                  <span className="absolute top-2 right-2 w-2 h-2 bg-[#8b5cf6] rounded-full" />
                </button>

                {/* Settings */}
                <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors">
                  <Settings className="w-5 h-5 text-[#b8c1ec]" />
                </button>

                {/* Profile Avatar */}
                <div className="flex items-center gap-3 pl-3 pr-4 py-2 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#6366f1]/20 border border-[#8b5cf6]/30 cursor-pointer hover:from-[#8b5cf6]/30 hover:to-[#6366f1]/30 transition-all">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#6366f1] flex items-center justify-center">
                    <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-body)' }}>
                      JD
                    </span>
                  </div>
                  <span className="text-sm text-[#e9d5ff] font-medium hidden lg:block" style={{ fontFamily: 'var(--font-body)' }}>
                    John Doe
                  </span>
                </div>

                {/* Sign Out Button */}
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 hover:bg-[#8b5cf6]/10 transition-all text-[#b8c1ec] hover:text-[#e9d5ff]">
                  <LogOut className="w-4 h-4" />
                  <span className="text-sm font-medium hidden xl:block" style={{ fontFamily: 'var(--font-body)' }}>
                    Sign Out
                  </span>
                </button>
              </div>
            </div>
          </div>
        </nav>

        {/* Dashboard Content */}
        <main className="max-w-[1600px] mx-auto px-6 lg:px-8 py-12">
          {/* Welcome Section */}
          <motion.div
            className="mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative mb-3">
              {/* Decorative sparkle accent behind heading */}
              <Sparkles className="absolute -left-3 top-1/2 -translate-y-1/2 w-16 h-16 text-[#8b5cf6] opacity-[0.08] -z-10" />
              <h2
                className="text-4xl lg:text-5xl tracking-tight bg-gradient-to-br from-[#f0f4ff] via-[#d4c5f9] to-[#c4b5fd] bg-clip-text text-transparent"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Welcome back
              </h2>
            </div>
            <p
              className="text-lg text-[#b8c1ec]"
              style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
            >
              Continue building your universe.
            </p>
          </motion.div>

          {/* Quick Stats Cards */}
          <motion.div
            className="grid md:grid-cols-3 gap-6 mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            {[
              {
                title: 'Anime Tracked',
                count: mockStats.anime,
                icon: Tv,
                gradient: 'from-[#c026d3] to-[#9333ea]',
                bgGradient: 'from-[#c026d3]/10 to-[#9333ea]/10',
                borderColor: 'border-[#c026d3]/30',
              },
              {
                title: 'Movies Tracked',
                count: mockStats.movies,
                icon: Film,
                gradient: 'from-[#8b5cf6] to-[#6366f1]',
                bgGradient: 'from-[#8b5cf6]/10 to-[#6366f1]/10',
                borderColor: 'border-[#8b5cf6]/30',
              },
              {
                title: 'Games Tracked',
                count: mockStats.games,
                icon: Gamepad2,
                gradient: 'from-[#3b82f6] to-[#1d4ed8]',
                bgGradient: 'from-[#3b82f6]/10 to-[#1d4ed8]/10',
                borderColor: 'border-[#3b82f6]/30',
              },
            ].map((stat) => (
              <motion.div
                key={stat.title}
                className={`relative p-6 rounded-2xl border ${stat.borderColor} bg-gradient-to-br ${stat.bgGradient} backdrop-blur-sm hover:scale-[1.02] transition-all duration-300 cursor-pointer group overflow-hidden`}
                whileHover={{ y: -4 }}
              >
                {/* Subtle glow on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                
                <div className="relative flex items-center justify-between">
                  <div>
                    <p
                      className="text-sm text-[#b8c1ec] mb-2"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                    >
                      {stat.title}
                    </p>
                    <p
                      className="text-4xl tracking-tight bg-gradient-to-br from-[#f0f4ff] to-[#d4c5f9] bg-clip-text text-transparent"
                      style={{ fontFamily: 'var(--font-display)' }}
                    >
                      {stat.count}
                    </p>
                  </div>
                  <div className={`p-4 rounded-xl bg-gradient-to-br ${stat.gradient} shadow-lg`}>
                    <stat.icon className="w-7 h-7 text-white" />
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Continue Tracking Section */}
          <motion.section
            className="mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Clock className="w-6 h-6 text-[#8b5cf6]" />
                <h3
                  className="text-2xl lg:text-3xl tracking-tight bg-gradient-to-br from-[#f0f4ff] to-[#d4c5f9] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Continue Tracking
                </h3>
              </div>
              <button
                className="text-sm text-[#8b5cf6] hover:text-[#a78bfa] transition-colors"
                style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
              >
                View All
              </button>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockRecentlyTracked.map((item) => (
                <motion.div
                  key={item.id}
                  className="group relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all duration-300 cursor-pointer"
                  whileHover={{ y: -6, scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Image */}
                  <div className="relative h-72 overflow-hidden">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    {/* Gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f]/60 to-transparent" />
                    
                    {/* Rating */}
                    <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#0a0a0f]/80 backdrop-blur-md">
                      <Star className="w-4 h-4 fill-[#fbbf24] text-[#fbbf24]" />
                      <span className="text-sm font-semibold text-white" style={{ fontFamily: 'var(--font-body)' }}>
                        {item.rating}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-5">
                    <h4
                      className="text-lg mb-2 text-[#f0f4ff] line-clamp-1"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                    >
                      {item.title}
                    </h4>
                    <p
                      className="text-sm text-[#8b5cf6] capitalize mb-1"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                    >
                      {item.type}
                    </p>
                    <p
                      className="text-sm text-[#b8c1ec]"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                    >
                      {item.progress}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.section>

          {/* Favorites Section */}
          <motion.section
            className="mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Star className="w-6 h-6 text-[#8b5cf6]" />
                <h3
                  className="text-2xl lg:text-3xl tracking-tight bg-gradient-to-br from-[#f0f4ff] to-[#d4c5f9] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Favorites
                </h3>
              </div>
              <button
                className="text-sm text-[#8b5cf6] hover:text-[#a78bfa] transition-colors"
                style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
              >
                View All
              </button>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockFavorites.map((item) => (
                <motion.div
                  key={item.id}
                  className="group relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all duration-300 cursor-pointer"
                  whileHover={{ y: -6, scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Image */}
                  <div className="relative h-72 overflow-hidden">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    {/* Gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f]/60 to-transparent" />
                    
                    {/* Rating */}
                    <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#0a0a0f]/80 backdrop-blur-md">
                      <Star className="w-4 h-4 fill-[#fbbf24] text-[#fbbf24]" />
                      <span className="text-sm font-semibold text-white" style={{ fontFamily: 'var(--font-body)' }}>
                        {item.rating}
                      </span>
                    </div>

                    {/* Favorite badge */}
                    <div className="absolute top-3 left-3 p-2 rounded-lg bg-[#8b5cf6]/80 backdrop-blur-md">
                      <Star className="w-4 h-4 fill-white text-white" />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-5">
                    <h4
                      className="text-lg mb-2 text-[#f0f4ff] line-clamp-1"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                    >
                      {item.title}
                    </h4>
                    <p
                      className="text-sm text-[#8b5cf6] capitalize"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                    >
                      {item.type}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.section>

          {/* Recent Reviews & Quick Actions Grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Recent Reviews - 2/3 width */}
            <motion.section
              className="lg:col-span-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <div className="flex items-center gap-3 mb-6">
                <TrendingUp className="w-6 h-6 text-[#8b5cf6]" />
                <h3
                  className="text-2xl lg:text-3xl tracking-tight bg-gradient-to-br from-[#f0f4ff] to-[#d4c5f9] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Recent Reviews
                </h3>
              </div>

              <div className="space-y-4">
                {mockReviews.map((review) => (
                  <div
                    key={review.id}
                    className="p-6 rounded-2xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4
                          className="text-lg text-[#f0f4ff] mb-1"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}
                        >
                          {review.title}
                        </h4>
                        <p
                          className="text-sm text-[#8b5cf6] capitalize"
                          style={{ fontFamily: 'var(--font-body)', fontWeight: 500 }}
                        >
                          {review.type}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < review.rating
                                ? 'fill-[#fbbf24] text-[#fbbf24]'
                                : 'text-[#4b5563]'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <p
                      className="text-[#b8c1ec] mb-3 leading-relaxed"
                      style={{ fontFamily: 'var(--font-body)', fontWeight: 400 }}
                    >
                      {review.review}
                    </p>
                    <p
                      className="text-xs text-[#6b7280]"
                      style={{ fontFamily: 'var(--font-body)' }}
                    >
                      {review.date}
                    </p>
                  </div>
                ))}
              </div>
            </motion.section>

            {/* Quick Actions & Your Library - 1/3 width */}
            <div className="space-y-8">
              {/* Quick Actions */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                <h3
                  className="text-2xl lg:text-3xl mb-6 tracking-tight bg-gradient-to-br from-[#f0f4ff] to-[#d4c5f9] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Quick Actions
                </h3>

                <div className="space-y-3">
                  {[
                    { title: 'Add Anime', icon: Tv, gradient: 'from-[#c026d3] to-[#9333ea]' },
                    { title: 'Add Movie', icon: Film, gradient: 'from-[#8b5cf6] to-[#6366f1]' },
                    { title: 'Add Game', icon: Gamepad2, gradient: 'from-[#3b82f6] to-[#1d4ed8]' },
                  ].map((action) => (
                    <button
                      key={action.title}
                      className={`w-full group flex items-center gap-3 p-4 rounded-xl bg-gradient-to-br ${action.gradient} hover:scale-[1.02] transition-all duration-300 shadow-lg hover:shadow-xl`}
                    >
                      <div className="p-2 rounded-lg bg-white/10">
                        <action.icon className="w-5 h-5 text-white" />
                      </div>
                      <span
                        className="font-semibold text-white"
                        style={{ fontFamily: 'var(--font-body)' }}
                      >
                        {action.title}
                      </span>
                      <Plus className="w-5 h-5 text-white ml-auto" />
                    </button>
                  ))}
                </div>
              </motion.section>

              {/* Your Library */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <h3
                  className="text-2xl lg:text-3xl mb-6 tracking-tight bg-gradient-to-br from-[#f0f4ff] to-[#d4c5f9] bg-clip-text text-transparent"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Your Library
                </h3>

                <div className="space-y-3">
                  {[
                    { title: 'Anime', count: mockStats.anime, icon: Tv, color: '#c026d3' },
                    { title: 'Movies', count: mockStats.movies, icon: Film, color: '#8b5cf6' },
                    { title: 'Games', count: mockStats.games, icon: Gamepad2, color: '#3b82f6' },
                  ].map((library) => (
                    <button
                      key={library.title}
                      className="w-full group flex items-center justify-between p-4 rounded-xl bg-gradient-to-br from-[#1a1a2e]/60 to-[#16162a]/60 border border-[#8b5cf6]/20 hover:border-[#8b5cf6]/40 transition-all duration-300"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg" style={{ backgroundColor: `${library.color}20` }}>
                          <library.icon className="w-5 h-5" style={{ color: library.color }} />
                        </div>
                        <span
                          className="font-semibold text-[#f0f4ff]"
                          style={{ fontFamily: 'var(--font-body)' }}
                        >
                          {library.title}
                        </span>
                      </div>
                      <span
                        className="text-2xl tracking-tight text-[#d4c5f9]"
                        style={{ fontFamily: 'var(--font-display)' }}
                      >
                        {library.count}
                      </span>
                    </button>
                  ))}
                </div>
              </motion.section>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}