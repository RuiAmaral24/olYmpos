import ItemDetails from './pages/ItemDetails';

export default function App() {
  return <ItemDetails />;
}